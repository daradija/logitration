#!/usr/bin/env python3
"""Núcleo A2A del edificio (0.8.1: F1 lectura + F3 escritura con política + F4 permisos y órdenes admin). Proceso HIJO de edificio.py: si cae, el edificio y las anclas siguen.

Qué hace: habla el protocolo A2A (Agent2Agent, a2a-protocol.org, especificación 1.0) por una puerta de LOOPBACK (127.0.0.1)
y, en F2, por el websocket saliente a luna (a2a_ws.py llama a `atiende`). Solo stdlib (Python 3.9). Nada de librerías.
  · tarjeta del edificio FIRMADA (JWS ES256, JCS RFC 8785), pública mínima y extendida (con Bearer);
  · una interfaz por sala con tenant = nombre de la sala (en la extendida);
  · habilidades de lectura: estado, ListTasks, GetTask, GetExtendedAgentCard; el contrato B2 va como extensión «edificio-b2/v1»;
  · almacén local sqlite (a2a/tareas.sqlite): tareas, contextos, messageId (idempotencia) y seguimiento.
  · 0.8.1 ESCRITURA: SendMessage a una sala = tarea SUBMITTED→WORKING→COMPLETED/FAILED/REJECTED/CANCELED; entra al buzón de la sala como mensaje
    «de un agente» (DATO) con autor «a2a:<cliente>». POR DELANTE de toda escritura va la política (a2a_politica.py: consigna, veto, confianza,
    «niega todo»), igual para la puerta de loopback y para el relé. Permiso pendiente de la sala = INPUT_REQUIRED; se contesta con
    SendMessage en el mismo taskId (DataPart {firma, n}; firma vieja = error, no actúa). Las órdenes cerradas son habilidades de alcance admin
    (las ejecuta edificio.py, el proceso padre, por estado/local/*.pedido firmado). Alcances de la ficha: lectura < escritura < admin.
Se enciende con config.json: "a2a": {"activo": true, "puerto": 8890}. Sin esa bandera, edificio.py no lo lanza.
Uso: python3 a2a.py servir | tarjeta | token
"""
import base64
import collections
import hashlib
import hmac
import json
import os
import re
import secrets
import socket
import sqlite3
import ssl
import sys
import threading
import time
import urllib.parse
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

AQUI = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, AQUI)
from a2a_comun import ErrorA2A, ahora_iso, WS, Cerrado, SUBPROTOCOLO, clave_aceptada   # noqa: E402
import a2a_politica as POL   # noqa: E402
DIR = os.path.join(AQUI, "a2a")
VERSION = "0.9.3"
INSTANTANEA = "instantanea-edificio"        # 0.9.3: tarea SOLO ADMIN con el cuerpo del antiguo latido (27 campos por agente + charla por sala + salida a la pasarela)
MAX_INSTANTANEA = 900 * 1024                 # la trama del relé admite 1 MiB
PROTOCOLO = "1.0"
EXT_B2 = "https://pyroboadvisor.org/a2a/ext/edificio-b2/v1"
EXT_AULA = "https://pyroboadvisor.org/a2a/ext/aula-huella/v1"       # 0.9.0 F8: cursos de Aula con huella y sello (a2a_aula.py, en luna)
SKILLS_AULA = {"lista-cursos": "Cursos de Aula publicados por este edificio, uno por artefacto con huella y sello (extensión aula-huella/v1, alcance lectura).",
               "lee-curso": "SendMessage {skill: «lee-curso», curso}: el curso como artefacto (url al paquete.tar, huella sha256 y sello). Exige A2A-Extensions con aula-huella/v1 (si no: -32008).",
               "verifica-sello": "SendMessage {skill: «verifica-sello», curso, huella, sello}: luna comprueba el sello (lectura).",
               "publica-curso": "SendMessage {skill: «publica-curso», curso, envio, inicio, fin, ficheros:[{ruta, texto}]} (alcance admin): publica un curso por lotes, como POST /build/aula/publica. Exige aula-huella/v1."}
LIMITE_CUERPO = 1 << 20
REFRESCO_S = 5
MAX_TAREAS = 400
ESTADOS_FINALES = ("TASK_STATE_COMPLETED", "TASK_STATE_FAILED", "TASK_STATE_CANCELED", "TASK_STATE_REJECTED")


# ------------------------------------------------------------------ utilidades: base64url, JCS, ES256 (P-256) en Python puro
def b64u(b):
    return base64.urlsafe_b64encode(b).rstrip(b"=").decode("ascii")


def b64u_dec(s):
    return base64.urlsafe_b64decode(s + "=" * (-len(s) % 4))


def limpia_vacios(x):
    """Quita None, "", [] y {} (como hace el verificador de referencia antes de canonicalizar; false y 0 se quedan)."""
    if isinstance(x, dict):
        d = {k: limpia_vacios(v) for k, v in x.items()}
        d = {k: v for k, v in d.items() if v is not None}
        return d or None
    if isinstance(x, list):
        l = [limpia_vacios(v) for v in x]
        l = [v for v in l if v is not None]
        return l or None
    if x == "":
        return None
    return x


def jcs(x):
    """RFC 8785 para lo que usamos: sin decimales, claves BMP. Orden por clave, sin espacios, UTF-8 sin escapar."""
    return json.dumps(x, sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False)


_P = 0xffffffff00000001000000000000000000000000ffffffffffffffffffffffff
_N = 0xffffffff00000000ffffffffffffffffbce6faada7179e84f3b9cac2fc632551
_G = (0x6b17d1f2e12c4247f8bce6e563a440f277037d812deb33a0f4a13945d898c296,
      0x4fe342e2fe1a7f9b8ee7eb4a7c0f9e162bce33576b315ececbb6406837bf51f5)


def _suma(p, q):
    if p is None:
        return q
    if q is None:
        return p
    if p[0] == q[0]:
        if (p[1] + q[1]) % _P == 0:
            return None
        m = (3 * p[0] * p[0] - 3) * pow(2 * p[1], -1, _P) % _P
    else:
        m = (q[1] - p[1]) * pow(q[0] - p[0], -1, _P) % _P
    x = (m * m - p[0] - q[0]) % _P
    return (x, (m * (p[0] - x) - p[1]) % _P)


def _mult(k, p):
    r = None
    while k:
        if k & 1:
            r = _suma(r, p)
        p = _suma(p, p)
        k >>= 1
    return r


def _k_rfc6979(d, h1):
    x = d.to_bytes(32, "big")
    h = (int.from_bytes(h1, "big") % _N).to_bytes(32, "big")
    v, k = b"\x01" * 32, b"\x00" * 32
    k = hmac.new(k, v + b"\x00" + x + h, hashlib.sha256).digest()
    v = hmac.new(k, v, hashlib.sha256).digest()
    k = hmac.new(k, v + b"\x01" + x + h, hashlib.sha256).digest()
    v = hmac.new(k, v, hashlib.sha256).digest()
    while True:
        v = hmac.new(k, v, hashlib.sha256).digest()
        c = int.from_bytes(v, "big")
        if 1 <= c < _N:
            return c
        k = hmac.new(k, v + b"\x00", hashlib.sha256).digest()
        v = hmac.new(k, v, hashlib.sha256).digest()


def es256_firma(d, mensaje):
    """JWS ES256: ECDSA P-256 sobre SHA-256, firma cruda r||s de 64 bytes."""
    h1 = hashlib.sha256(mensaje).digest()
    z = int.from_bytes(h1, "big")
    while True:
        k = _k_rfc6979(d, h1)
        r = _mult(k, _G)[0] % _N
        s = pow(k, -1, _N) * (z + r * d) % _N
        if r and s:
            return r.to_bytes(32, "big") + s.to_bytes(32, "big")


def es256_verifica(pub, mensaje, firma):
    if len(firma) != 64:
        return False
    r, s = int.from_bytes(firma[:32], "big"), int.from_bytes(firma[32:], "big")
    if not (1 <= r < _N and 1 <= s < _N):
        return False
    z, w = int.from_bytes(hashlib.sha256(mensaje).digest(), "big"), pow(s, -1, _N)
    p = _suma(_mult(z * w % _N, _G), _mult(r * w % _N, pub))
    return p is not None and p[0] % _N == r


# ------------------------------------------------------------------ ficheros propios (a2a/): clave de firma y ficha local
def _escribe600(ruta, texto):
    fd = os.open(ruta, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w") as f:
        f.write(texto)
    os.chmod(ruta, 0o600)


def clave_firma(nombre_edificio):
    """(d, (x, y), kid): la clave ES256 del edificio. Se crea la primera vez (a2a/clave.json, 600) y no cambia."""
    os.makedirs(DIR, mode=0o700, exist_ok=True)
    ruta = os.path.join(DIR, "clave.json")
    try:
        with open(ruta) as f:
            j = json.load(f)
        d = int(j["d"], 16)
    except (OSError, ValueError, KeyError):
        d = secrets.randbelow(_N - 1) + 1
        j = {"d": "%064x" % d, "kid": "edificio-%s-%s" % (nombre_edificio, secrets.token_hex(3)), "creada": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())}
        _escribe600(ruta, json.dumps(j))
    return d, _mult(d, _G), j["kid"]


def jwk_publica(nombre_edificio):
    d, (x, y), kid = clave_firma(nombre_edificio)
    return {"kty": "EC", "crv": "P-256", "x": b64u(x.to_bytes(32, "big")), "y": b64u(y.to_bytes(32, "big")),
            "kid": kid, "use": "sig", "alg": "ES256"}


def token_local():
    """Bearer de la puerta de loopback (a2a/token_local, 600). Quien pueda leer ese fichero ya es el usuario del edificio."""
    ruta = os.path.join(DIR, "token_local")
    try:
        with open(ruta) as f:
            t = f.read().strip()
        if t.startswith("a2al-") and len(t) > 20:
            return t
    except OSError:
        pass
    os.makedirs(DIR, mode=0o700, exist_ok=True)
    t = "a2al-" + secrets.token_urlsafe(24)
    _escribe600(ruta, t + "\n")
    return t


# ------------------------------------------------------------------ estado de las salas (el contrato B2) leído SIN escribir
def estado_salas():
    """Lo mismo que el latido sube a luna (edificio.latido_json) y de ahí sale /build/estado, en forma de contrato B2. Solo lectura."""
    import edificio as E
    cfg = E.lee_json(E.CONFIG, {})
    j = E.latido_json(cfg, con_charla=False)
    salas = []
    for a in j["agentes"]:
        s = {"sala": a["nombre"], "numero": a.get("sala"), "tipo": a.get("tipo"), "activo": bool(a.get("activo")),
             "estado": a.get("estado_sala") or ("idle" if a.get("activo") else "baja"), "estado_detalle": a.get("estado"),
             "que": a.get("que") or "", "modelo": a.get("modelo") or "", "ctx": a.get("contexto"), "via": a.get("via") or "",
             "supervisada": bool(a.get("supervisada")), "caidas": a.get("caidas"), "t": a.get("t"), "t_iso": a.get("t_iso")}
        if a.get("retenida"):
            s["retenida"] = a["retenida"]
        salas.append({k: v for k, v in s.items() if v is not None})
    return {"edificio": j["edificio"], "version": j["version"], "t": int(time.time()), "salas": salas}


# ------------------------------------------------------------------ almacén sqlite (tareas y contextos)
class Almacen:
    def __init__(self, ruta):
        self.ruta = ruta
        self.cerrojo = threading.Lock()
        self.db = sqlite3.connect(ruta, check_same_thread=False, isolation_level=None)
        self.db.execute("PRAGMA journal_mode=WAL")
        self.db.executescript("""
            CREATE TABLE IF NOT EXISTS tareas(id TEXT PRIMARY KEY, contexto TEXT, tenant TEXT, estado TEXT, t_iso TEXT, t REAL, json TEXT);
            CREATE INDEX IF NOT EXISTS tareas_t ON tareas(t DESC);
            CREATE TABLE IF NOT EXISTS contextos(id TEXT PRIMARY KEY, tenant TEXT, creado TEXT);
            CREATE TABLE IF NOT EXISTS mensajes(mid TEXT, quien TEXT, tarea TEXT, PRIMARY KEY(mid, quien));
            CREATE TABLE IF NOT EXISTS seguimiento(tarea TEXT PRIMARY KEY, json TEXT);""")
        os.chmod(ruta, 0o600)

    def tarea_de_mensaje(self, mid, quien):
        with self.cerrojo:
            r = self.db.execute("SELECT tarea FROM mensajes WHERE mid=? AND quien=?", (mid, quien)).fetchone()
        return self.tarea(r[0]) if r else None

    def anota_mensaje(self, mid, quien, tarea):
        with self.cerrojo:
            self.db.execute("INSERT OR IGNORE INTO mensajes VALUES(?,?,?)", (mid, quien, tarea))

    def sigue(self, tarea, seg=None, borra=False):
        with self.cerrojo:
            if borra:
                self.db.execute("DELETE FROM seguimiento WHERE tarea=?", (tarea,))
            elif seg is not None:
                self.db.execute("INSERT OR REPLACE INTO seguimiento VALUES(?,?)", (tarea, json.dumps(seg, ensure_ascii=False)))
            else:
                r = self.db.execute("SELECT json FROM seguimiento WHERE tarea=?", (tarea,)).fetchone()
                return json.loads(r[0]) if r else None

    def seguidas(self):
        with self.cerrojo:
            return [(r[0], json.loads(r[1])) for r in self.db.execute("SELECT tarea, json FROM seguimiento").fetchall()]

    def guarda(self, tarea, tenant):
        with self.cerrojo:
            self.db.execute("INSERT OR REPLACE INTO tareas VALUES(?,?,?,?,?,?,?)",
                            (tarea["id"], tarea["contextId"], tenant, tarea["status"]["state"], tarea["status"]["timestamp"],
                             time.time(), json.dumps(tarea, ensure_ascii=False)))
            self.db.execute("INSERT OR IGNORE INTO contextos VALUES(?,?,?)", (tarea["contextId"], tenant, ahora_iso()))
            self.db.execute("DELETE FROM tareas WHERE id NOT LIKE 'estado-%' AND id NOT IN "
                            "(SELECT id FROM tareas WHERE id NOT LIKE 'estado-%' ORDER BY t DESC LIMIT ?)", (MAX_TAREAS,))
            self.db.execute("DELETE FROM mensajes WHERE tarea NOT IN (SELECT id FROM tareas)")
            self.db.execute("DELETE FROM seguimiento WHERE tarea NOT IN (SELECT id FROM tareas)")

    def olvida_estados(self, vigentes):
        """0.8.2: borra las tareas «estado-<sala>» de salas que ya no están (el 04-11 agua seguía ofreciendo a2a_prueba, a2a_sesion y a2a_vieja, borradas horas antes)."""
        with self.cerrojo:
            for (i,) in self.db.execute("SELECT id FROM tareas WHERE id LIKE 'estado-%'").fetchall():
                if i not in vigentes:
                    self.db.execute("DELETE FROM tareas WHERE id=?", (i,))

    def tarea(self, ide):
        with self.cerrojo:
            r = self.db.execute("SELECT json FROM tareas WHERE id=?", (ide,)).fetchone()
        return json.loads(r[0]) if r else None

    def lista(self, tenant=None, contexto=None, estado=None):
        q, a = "SELECT json FROM tareas WHERE 1=1", []
        for col, v in (("tenant", tenant), ("contexto", contexto), ("estado", estado)):
            if v:
                q += " AND %s=?" % col
                a.append(v)
        with self.cerrojo:
            return [json.loads(r[0]) for r in self.db.execute(q + " ORDER BY t DESC, id", a).fetchall()]


# ------------------------------------------------------------------ el núcleo
class Nucleo:
    def __init__(self, cfg):
        self.cfg = cfg
        self.nombre = (cfg.get("nombre") or "edificio")
        os.makedirs(DIR, mode=0o700, exist_ok=True)
        self.almacen = Almacen(os.path.join(DIR, "tareas.sqlite"))
        self.token = token_local()
        self.cache_tarjeta = {}
        self.escribe = threading.RLock()                   # una escritura o un avance de tareas a la vez
        self.ritmos = {}
        import edificio as E
        self.pol = POL.Politica(os.path.join(DIR, "politica"), self.nombre, lambda: E.lee_json(E.CONFIG, {}))
        os.makedirs(self.pol.carpeta, mode=0o700, exist_ok=True)
        self.relay = None
        self.ultimo = None
        self.cerrojo = threading.Lock()
        self.cerrojo_inst = threading.Lock()
        self._inst = None
        self.refresca()

    # --- estado → tareas «estado-<sala>» (una por sala + «estado-edificio»); se rehacen cada REFRESCO_S, sin tocar las sesiones
    def tarea_estado(self, ide, tenant, datos, resumen):
        ctx = "ctx-" + (tenant or "edificio")
        ts = ahora_iso()
        return {"id": ide, "contextId": ctx,
                "status": {"state": "TASK_STATE_COMPLETED", "timestamp": ts,
                           "message": {"messageId": "m-" + ide, "role": "ROLE_AGENT", "parts": [{"text": resumen, "mediaType": "text/plain"}]}},
                "artifacts": [{"artifactId": "estado", "name": "estado", "description": "Estado de la sala en el contrato común B2",
                               "parts": [{"data": datos, "mediaType": "application/json"}], "extensions": [EXT_B2]}],
                "metadata": {EXT_B2: datos}}

    def refresca(self):
        e = estado_salas()
        with self.cerrojo:
            self.ultimo = e
            self.salas = {s["sala"]: s for s in e["salas"]}
        resumen = "%d salas: %s" % (len(e["salas"]), ", ".join("%s %s" % (s["sala"], s["estado"]) for s in e["salas"]))
        self.almacen.guarda(self.tarea_estado("estado-edificio", "", e, resumen), "")
        for s in e["salas"]:
            self.almacen.guarda(self.tarea_estado("estado-" + s["sala"], s["sala"], s, "%s: %s" % (s["sala"], s["estado"])), s["sala"])
        self.almacen.olvida_estados({"estado-" + s["sala"] for s in e["salas"]} | {"estado-edificio"})   # 0.8.2: una sala que ya no existe deja de aparecer

    def instantanea(self):
        """0.9.3: lo que antes subía el latido, como UNA tarea que no se guarda (se hace al pedirla; caché de 1 s). Solo admin. El cuerpo es latido_json(cfg) con la charla
        ENTERA de cada sala y, aparte, `pasarela_salida` (≤5 mensajes de las sesiones a la pasarela que luna recoge y acusa con la orden `acusa_pasarela`)."""
        import edificio as E
        with self.cerrojo_inst:
            ahora = time.time()
            if self._inst and ahora - self._inst[0] < 1.0:
                return self._inst[1]
            j = E.latido_json(E.lee_json(E.CONFIG, {}), todo=True)
            j["pasarela_salida"] = [{"id": m.get("id"), "de": m.get("de"), "texto": m.get("texto")} for m in E.lineas(E.PAS_SALIDA)[:5] if m.get("id")]
            j["t_instantanea"] = ahora
            while len(json.dumps(j, ensure_ascii=False)) > MAX_INSTANTANEA and any(len(v) > 1 for v in j["charla"].values()):
                j["charla"] = {k: v[len(v) // 2:] for k, v in j["charla"].items()}      # no cabe: la mitad más reciente de cada charla
            ts = ahora_iso()
            t = {"id": INSTANTANEA, "contextId": "ctx-edificio",
                 "status": {"state": "TASK_STATE_COMPLETED", "timestamp": ts,
                            "message": {"messageId": "m-" + INSTANTANEA, "role": "ROLE_AGENT", "parts": [{"text": "%d agentes" % len(j["agentes"]), "mediaType": "text/plain"}]}},
                 "artifacts": [{"artifactId": "instantanea", "name": "instantanea", "description": "Cuerpo del antiguo latido (solo admin)",
                                "parts": [{"data": j, "mediaType": "application/json"}]}]}
            self._inst = (ahora, t)
            return t

    # --- tarjetas
    def interfaces(self, base, extendida):
        ifs = [{"url": base + "/rpc", "protocolBinding": "JSONRPC", "protocolVersion": PROTOCOLO},
               {"url": base + "/rest", "protocolBinding": "HTTP+JSON", "protocolVersion": PROTOCOLO}]
        if extendida:
            ifs += [{"url": base + "/rpc", "protocolBinding": "JSONRPC", "protocolVersion": PROTOCOLO, "tenant": s}
                    for s in sorted(set(self.salas) | set(self.TENANTS_EXTRA))]
        return ifs

    def tarjeta(self, base, extendida=False):
        """Tarjeta del edificio, firmada. Pública: mínima. Extendida (Bearer): una interfaz por sala (tenant) y el resumen B2."""
        clave = (base, extendida)
        with self.cerrojo:
            salas = dict(self.salas)
            e = self.ultimo
        ext = {"uri": EXT_B2, "description": "Contrato común de estado de sala (idle/busy/caida/baja, modelo, ctx, caidas, via) del edificio."}
        # 0.9.0: «required» en A2A 1.0 es de TODA la extensión, no de una habilidad; aquí va false y las habilidades de Aula la EXIGEN en el servidor (ExtensionSupportRequiredError -32008)
        ext_aula = {"uri": EXT_AULA, "description": "Cursos de Aula con huella (sha256) y sello: las habilidades de Aula exigen esta extensión en la cabecera A2A-Extensions.",
                    "params": {"requeridaEn": sorted(SKILLS_AULA), "huella": "sha256-manifiesto-v1"}}
        # «required» es un bool simple (no optional): con false se OMITE (§8.4.1: valores por defecto fuera); si no, la firma no verifica
        if extendida:
            ext["params"] = {"salas": [{k: s[k] for k in ("sala", "estado", "tipo", "modelo", "ctx") if k in s} for s in e["salas"]]}
        habil = lambda i, n, d, t: {"id": i, "name": n, "description": d, "tags": t, "inputModes": ["text/plain", "application/json"],
                                    "outputModes": ["application/json"]}
        if self.SOLO_LECTURA:
            return self.tarjeta_firmada(base, extendida, clave, self.card_solo_lectura(base, extendida, salas, e, ext, habil))
        card = {"name": "Edificio " + self.nombre,
                "description": "Edificio de agentes de PyRoboAdvisor. Lee el estado de las salas; con una ficha de escritura manda mensajes a una sala (una tarea por mensaje, siempre detrás de la política del edificio); con una de admin da las órdenes cerradas y contesta permisos.",
                "supportedInterfaces": self.interfaces(base, extendida),
                "provider": {"organization": "PyRoboAdvisor", "url": "https://pyroboadvisor.org"},
                "version": VERSION,
                "capabilities": {"streaming": False, "pushNotifications": False, "extendedAgentCard": True, "extensions": [ext, ext_aula]},
                "securitySchemes": {"bearer": {"httpAuthSecurityScheme": {"scheme": "Bearer", "description": "Ficha a2a- del edificio, con alcance lectura, escritura o admin"}}},
                "securityRequirements": [{"schemes": {"bearer": {"list": []}}}],
                "defaultInputModes": ["text/plain", "application/json"], "defaultOutputModes": ["application/json", "text/plain"],
                "skills": [habil("estado", "Estado", "Estado de una sala (o del edificio entero) en el contrato B2. SendMessage con el texto «estado» y tenant = sala.", ["estado", "sala"]),
                           habil("listar", "Listar tareas", "ListTasks: las tareas del edificio, la más reciente primero.", ["tareas"]),
                           habil("tarea", "Consultar tarea", "GetTask por identificador.", ["tareas"]),
                           habil("tarjeta-extendida", "Tarjeta extendida", "GetExtendedAgentCard (con Bearer): salas e interfaces por tenant.", ["tarjeta"]),
                           habil("mensaje", "Mensaje a una sala", "SendMessage con texto y tenant = sala (alcance escritura): la sala lo recibe como dato de otro agente; la respuesta llega como artefacto. La política del edificio puede rechazarlo (REJECTED con motivo). CancelTask lo retira si aún no se entregó.", ["escritura", "sala"]),
                           *[habil(k, "Aula: " + k, v, ["aula", "curso"]) for k, v in sorted(SKILLS_AULA.items())],
                           habil("permiso", "Contestar un permiso", "Una tarea en INPUT_REQUIRED trae un DataPart {firma, opciones}; se contesta con SendMessage en el mismo taskId y contextId con un DataPart {firma, n} (alcance admin). Firma vieja: error y no se actúa.", ["admin", "permiso"])]
                          + [habil("orden-" + k, "Orden: " + k, "SendMessage con DataPart {skill: «%s», args: {…}} (alcance admin). Lista cerrada: lo que no esté aquí se rechaza." % k, ["admin", "orden"]) for k in POL.SKILLS_ADMIN]}
        return self.tarjeta_firmada(base, extendida, clave, card)

    def tarjeta_firmada(self, base, extendida, clave, card):
        huella = hashlib.sha256(jcs(limpia_vacios(card)).encode()).hexdigest()
        c = self.cache_tarjeta.get(clave)
        if c and c[0] == huella:
            return c[1]
        d, _, kid = clave_firma(self.nombre)
        cuerpo = jcs(limpia_vacios(card))
        prot = b64u(jcs({"alg": "ES256", "typ": "JOSE", "kid": kid, "jku": base + "/.well-known/jwks.json"}).encode())
        firma = es256_firma(d, (prot + "." + b64u(cuerpo.encode())).encode("ascii"))
        card = dict(card, signatures=[{"protected": prot, "signature": b64u(firma)}])
        self.cache_tarjeta[clave] = (huella, card)
        return card

    def card_solo_lectura(self, base, extendida, salas, e, ext, habil):
        """Tarjeta del edificio de SOLO LECTURA (0.8.2, el Mac): estado de sus salas y tareas; ninguna habilidad de escritura."""
        return {"name": "Edificio " + self.nombre,
                "description": "Edificio de agentes de PyRoboAdvisor, SOLO LECTURA: ofrece el estado de sus salas (contrato B2) y, si lo hay, un agente de encargos. No admite mensajes ni órdenes.",
                "supportedInterfaces": self.interfaces(base, extendida),
                "provider": {"organization": "PyRoboAdvisor", "url": "https://pyroboadvisor.org"},
                "version": VERSION,
                "capabilities": {"streaming": False, "pushNotifications": False, "extendedAgentCard": True, "extensions": [ext]},
                "securitySchemes": {"bearer": {"httpAuthSecurityScheme": {"scheme": "Bearer", "description": "Ficha a2a- del edificio, con alcance lectura"}}},
                "securityRequirements": [{"schemes": {"bearer": {"list": []}}}],
                "defaultInputModes": ["text/plain", "application/json"], "defaultOutputModes": ["application/json", "text/plain"],
                "skills": [habil("estado", "Estado", "Estado de una sala (o del edificio entero) en el contrato B2. SendMessage con el texto «estado» y tenant = sala.", ["estado", "sala"]),
                           habil("listar", "Listar tareas", "ListTasks: las tareas del edificio, la más reciente primero (tenant «puente»: los encargos).", ["tareas"]),
                           habil("tarea", "Consultar tarea", "GetTask por identificador.", ["tareas"]),
                           habil("tarjeta-extendida", "Tarjeta extendida", "GetExtendedAgentCard (con Bearer): salas e interfaces por tenant.", ["tarjeta"])]}

    def jwks(self):
        return {"keys": [jwk_publica(self.nombre)]}

    # --- operaciones A2A (las mismas para loopback y para el websocket de F2)
    def comprueba_tenant(self, tenant):
        if tenant and tenant not in self.salas and tenant not in self.TENANTS_EXTRA:
            raise ErrorA2A("InvalidParamsError", "tenant desconocido", tenant=str(tenant)[:40])

    def atiende(self, metodo, p, base, caller=None):
        """Una operación A2A ya autenticada: devuelve el resultado (dict) o lanza ErrorA2A. caller = {id, alcance} (loopback: LOCAL).
        Las lecturas no pasan por la política; TODA escritura sí (enviar, cancela), venga por la puerta que venga."""
        caller = caller or self.LOCAL
        p = p if isinstance(p, dict) else {}
        tenant = p.get("tenant") or ""
        if not isinstance(tenant, str):
            raise ErrorA2A("InvalidParamsError", "tenant debe ser texto")
        if metodo == "GetExtendedAgentCard":
            return self.tarjeta(base, True)
        if metodo == "GetTask" and str(p.get("id") or "") == INSTANTANEA and not self.SOLO_LECTURA:
            self.exige(caller, "admin")
            return self.recorta(self.instantanea(), None, True)
        if metodo == "GetTask":
            t = self.almacen.tarea(str(p.get("id") or ""))
            if not t:
                raise ErrorA2A("TaskNotFoundError", "La tarea no existe", taskId=str(p.get("id") or "")[:60])
            return self.recorta(t, p.get("historyLength"), True)
        if metodo == "ListTasks":
            self.comprueba_tenant(tenant)
            ts = self.almacen.lista(tenant or None, p.get("contextId") or None, p.get("status") or None)
            try:
                tam = max(1, min(100, int(p.get("pageSize") or 50)))
                ini = int(p.get("pageToken") or 0)
            except (TypeError, ValueError):
                raise ErrorA2A("InvalidParamsError", "pageSize/pageToken no válidos")
            pag = ts[ini:ini + tam]
            return {"tasks": [self.recorta(t, p.get("historyLength"), bool(p.get("includeArtifacts"))) for t in pag],
                    "nextPageToken": str(ini + tam) if ini + tam < len(ts) else "", "pageSize": tam, "totalSize": len(ts)}
        if metodo == "SendMessage":
            return self.enviar(p, tenant, caller)
        if metodo in ("SendStreamingMessage", "SubscribeToTask"):
            raise ErrorA2A("UnsupportedOperationError", "El streaming no está habilitado (capabilities.streaming = false)")
        if metodo == "CancelTask":
            return self.cancela(p, caller)
        if "PushNotification" in metodo:
            raise ErrorA2A("PushNotificationNotSupportedError", "Las notificaciones push no están soportadas")
        raise ErrorA2A("MethodNotFoundError", "Método no encontrado", metodo=str(metodo)[:40])

    # =================================================================== F3/F4: ESCRITURA (siempre detrás de la política)
    TENANTS_EXTRA = ()                                    # 0.8.2: tenants que no son salas (en «sol»: «puente», los encargos)
    SOLO_LECTURA = False                                  # 0.8.2: el edificio «sol» (el Mac) hereda esta clase con True: nada de escribir, por ninguna puerta
    LOCAL = {"id": "local", "alcance": "admin"}           # la puerta de loopback (Bearer a2al-): quien lee el token ya es el usuario del edificio
    NIVEL = {"lectura": 0, "escritura": 1, "admin": 2}
    TIMEOUT_SALA_S = 300
    TIMEOUT_ORDEN_S = 120

    def exige(self, caller, nivel):
        alc = (caller or {}).get("alcance")
        if self.NIVEL.get(alc, -1) < self.NIVEL[nivel]:
            raise ErrorA2A("PermissionDeniedError", "Hace falta alcance «%s» (la ficha tiene «%s»)" % (nivel, str(alc)[:20]))

    def ritmo(self, cid):
        """Tope por cliente: 20 escrituras por minuto."""
        ahora = time.time()
        q = self.ritmos.setdefault(cid, collections.deque())
        while q and q[0] < ahora - 60:
            q.popleft()
        if len(q) >= 20:
            raise ErrorA2A("InvalidRequestError", "demasiadas escrituras seguidas (20 por minuto y ficha)")
        q.append(ahora)

    def tarea_nueva(self, tenant, m, cid, estado, texto, ctx=None):
        ide = "t-" + secrets.token_hex(8)
        cx = m.get("contextId") if isinstance(m.get("contextId"), str) and 0 < len(m["contextId"]) <= 64 else None
        hist = {k: m[k] for k in ("messageId", "role", "parts") if k in m}
        hist.update(taskId=ide, contextId=cx or ctx or "c-" + secrets.token_hex(6))
        t = {"id": ide, "contextId": hist["contextId"],
             "status": {"state": estado, "timestamp": ahora_iso(), "message": self.msg_agente(ide, texto)},
             "history": [hist], "metadata": {EXT_B2: {"sala": tenant, "autor": "a2a:" + cid}}}
        return t

    @staticmethod
    def msg_agente(ide, texto, datos=None):
        partes = [{"text": texto, "mediaType": "text/plain"}]
        if datos is not None:
            partes.append({"data": datos, "mediaType": "application/json"})
        return {"messageId": "m-%s-%s" % (ide, secrets.token_hex(3)), "role": "ROLE_AGENT", "parts": partes}

    def pon_estado(self, t, estado, texto, datos=None, artefacto=None):
        t["status"] = {"state": estado, "timestamp": ahora_iso(), "message": self.msg_agente(t["id"], texto, datos)}
        if artefacto:
            t["artifacts"] = [artefacto]
        self.almacen.guarda(t, (t.get("metadata", {}).get(EXT_B2) or {}).get("sala") or "")
        return t

    def rechaza(self, tenant, m, cid, motivo, mid):
        t = self.tarea_nueva(tenant, m, cid, "TASK_STATE_REJECTED", motivo)
        t["metadata"][EXT_B2]["politica"] = True
        self.almacen.guarda(t, tenant)
        if mid:
            self.almacen.anota_mensaje(mid, cid, t["id"])
        return {"task": t}

    def enviar(self, p, tenant, caller):
        """SendMessage. Lectura: solo «estado». Escritura/admin: política → entrega. Admin: además órdenes cerradas y permisos."""
        m = p.get("message")
        if not isinstance(m, dict) or not isinstance(m.get("parts"), list) or not m["parts"]:
            raise ErrorA2A("InvalidParamsError", "message.parts: hace falta al menos una parte")
        cid = str((caller or {}).get("id") or "?")[:40]
        mid = m.get("messageId") if isinstance(m.get("messageId"), str) and 0 < len(m["messageId"]) <= 100 else None
        texto = " ".join(x.get("text", "") for x in m["parts"] if isinstance(x, dict) and isinstance(x.get("text"), str)).strip()
        datos = next((x["data"] for x in m["parts"] if isinstance(x, dict) and isinstance(x.get("data"), dict)), {})
        skill = datos.get("skill")
        es_estado = texto.lower() == "estado" or skill == "estado"
        if es_estado:                                             # lectura: no entrega nada a nadie
            self.comprueba_tenant(tenant)
            self.refresca()
            t = self.almacen.tarea("estado-" + (tenant or "edificio"))
            return {"task": self.recorta(t, None, True)}
        if self.SOLO_LECTURA:
            raise ErrorA2A("PermissionDeniedError", "Este edificio es de solo lectura: no admite mensajes ni órdenes")
        self.exige(caller, "escritura")
        if mid:                                                   # IDEMPOTENCIA: el mismo messageId del mismo cliente devuelve la misma tarea
            previo = self.almacen.tarea_de_mensaje(mid, cid)
            if previo:
                return {"task": self.recorta(previo, None, True)}
        with self.escribe:
            ok, motivo = self.pol.puerta()                        # «niega todo» y «sin consigna»: antes de mirar nada más, para TODA escritura
            if not ok:
                return self.rechaza(tenant, m, cid, "Rechazado por la política: " + motivo, mid)
            if m.get("taskId"):
                return self.continua(m, texto, datos, caller, cid, mid)
            if skill is not None:
                return self.orden_admin(m, skill, datos, tenant, caller, cid, mid)
            return self.mensaje_a_sala(m, tenant, texto, datos, caller, cid, mid)

    def mensaje_a_sala(self, m, tenant, texto, datos, caller, cid, mid):
        import edificio as E
        alc = caller["alcance"]
        if not tenant:
            return self.rechaza(tenant, m, cid, "Rechazado: falta el tenant (la sala a la que va el mensaje).", mid)
        if tenant not in self.salas:
            raise ErrorA2A("InvalidParamsError", "tenant desconocido", tenant=str(tenant)[:40])
        completo = texto + ((" " + json.dumps(datos, ensure_ascii=False)) if datos else "")
        if not texto:
            return self.rechaza(tenant, m, cid, "Rechazado: el mensaje no lleva texto.", mid)
        self.ritmo(cid)
        ok, motivo = self.pol.autoriza_envio(alc, tenant, completo)
        if not ok:
            return self.rechaza(tenant, m, cid, "Rechazado por la política: " + motivo, mid)
        if tenant not in E.agentes_def() or tenant in (E.pasarela_nombre(), E.MANT_NOMBRE):
            return self.rechaza(tenant, m, cid, "Rechazado: esa sala no admite mensajes de fuera.", mid)
        t = self.tarea_nueva(tenant, m, cid, "TASK_STATE_SUBMITTED", "Recibido; lo paso a la sala.")
        self.almacen.guarda(t, tenant)
        if mid:
            self.almacen.anota_mensaje(mid, cid, t["id"])
        buzon_id = secrets.token_hex(6)
        previos = [c.get("uuid") for c in E.lineas(os.path.join(E.ESTADO, tenant + ".charla.jsonl")) if c.get("quien") == tenant][-80:]
        try:
            E._buzon(tenant, buzon_id, "agente", texto[:4000], desde=re.sub(r"[^a-z0-9_-]", "", cid.lower())[:24] or "a2a", a2a="a2a:" + cid)
        except OSError as e:
            self.pon_estado(t, "TASK_STATE_FAILED", "No pude dejar el mensaje en el buzón de la sala: %s" % type(e).__name__)
            return {"task": t}
        self.almacen.sigue(t["id"], {"tipo": "mensaje", "sala": tenant, "buzon": buzon_id, "previos": previos, "t_envio": time.time(), "cid": cid,
                                     "alcance": alc, "timeout": self.cfg_num("timeout_sala_s", self.TIMEOUT_SALA_S)})
        self.pon_estado(t, "TASK_STATE_WORKING", "Entregado a la sala «%s»; espero su respuesta." % tenant)
        return {"task": t}

    def cfg_num(self, clave, defecto):
        v = (self.cfg.get("a2a") or {}).get(clave)
        return v if isinstance(v, (int, float)) and not isinstance(v, bool) and 5 <= v <= 3600 else defecto

    # --- F4a: contestar un permiso (INPUT_REQUIRED)
    def continua(self, m, texto, datos, caller, cid, mid):
        import edificio as E
        self.exige(caller, "admin")                               # dar un permiso a una sesión es lo más delicado: solo admin
        t = self.almacen.tarea(str(m["taskId"])[:80])
        if not t:
            raise ErrorA2A("TaskNotFoundError", "La tarea no existe", taskId=str(m["taskId"])[:60])
        if m.get("contextId") and m["contextId"] != t["contextId"]:
            raise ErrorA2A("InvalidParamsError", "contextId no coincide con el de la tarea")
        if t["status"]["state"] != "TASK_STATE_INPUT_REQUIRED":
            raise ErrorA2A("InvalidParamsError", "La tarea no espera nada ahora (estado %s)" % t["status"]["state"].replace("TASK_STATE_", ""))
        seg = self.almacen.sigue(t["id"]) or {}
        sala = seg.get("sala")
        firma, n = datos.get("firma"), datos.get("n")
        if not sala or not isinstance(firma, str) or not firma or isinstance(n, bool) or not isinstance(n, int):
            raise ErrorA2A("InvalidParamsError", "Para contestar hace falta un dato {firma, n}")
        if texto and self.pol.veta(texto, self.pol.confianza(caller["alcance"])):
            raise ErrorA2A("InvalidParamsError", "El texto que acompaña al permiso contiene algo vetado")
        self.ritmo(cid)
        r = E.ejecuta({"id": secrets.token_hex(6), "tipo": "permiso", "args": {"agente": sala, "firma": firma, "n": n, "texto": texto[:500], "autor": "enlace"}})
        if not r.get("ok"):                                       # firma vieja u opción no válida: error, NO se actúa y la tarea sigue esperando
            raise ErrorA2A("InvalidParamsError", str(r.get("r"))[:200], taskId=t["id"])
        t.setdefault("history", []).append({k: m[k] for k in ("messageId", "role", "parts") if k in m})
        if seg.get("tipo") == "permiso":                          # la tarea «permiso-<sala>» solo existía para esto
            self.almacen.sigue(t["id"], borra=True)
            self.pon_estado(t, "TASK_STATE_COMPLETED", "Permiso contestado (opción %d)." % n)
        else:
            seg.update(permiso_firma=None, t_envio=max(seg.get("t_envio", 0), time.time()))
            self.almacen.sigue(t["id"], seg)
            self.pon_estado(t, "TASK_STATE_WORKING", "Permiso contestado (opción %d); la sala sigue." % n)
        if mid:
            self.almacen.anota_mensaje(mid, cid, t["id"])
        return {"task": t}

    # --- F4b: las órdenes cerradas como habilidades de admin
    def orden_admin(self, m, skill, datos, tenant, caller, cid, mid):
        import edificio as E
        self.exige(caller, "admin")
        if not isinstance(skill, str) or skill not in POL.SKILLS_ADMIN:
            return self.rechaza(tenant, m, cid, "Rechazado: «%s» no está en la lista cerrada de habilidades de admin (%s)." % (
                str(skill)[:40], ", ".join(POL.SKILLS_ADMIN)), mid)
        self.ritmo(cid)
        args = datos.get("args") if isinstance(datos.get("args"), dict) else {}
        ags = {n: {"pasarela": n == E.pasarela_nombre()} for n in E.agentes_def()}
        try:
            _, nombre = self.pol.prepara_accion(skill, args, ags, E.plano()["directivos"], E.pasarela_nombre() or "", VERSION)
        except ValueError as e:
            return self.rechaza(tenant, m, cid, "Rechazado por la política: %s." % e, mid)
        a = self.pol.filtra_args(skill, args, nombre)
        if skill == "acusa_pasarela":                              # 0.9.3: se resuelve aquí mismo (solo toca estado/pasarela_salida.jsonl)
            ids = [x for x in (a.get("ids") if isinstance(a.get("ids"), list) else []) if isinstance(x, str) and re.match(r"^[A-Za-z0-9]{1,40}$", x)][:20]
            E.acusa_pasarela(set(ids))
            t = self.tarea_nueva("", m, cid, "TASK_STATE_COMPLETED", "Acusados %d mensajes a la pasarela." % len(ids), ctx="ctx-admin")
            self.almacen.guarda(t, "")
            if mid:
                self.almacen.anota_mensaje(mid, cid, t["id"])
            return {"task": t}
        if skill == "mensaje_de":                                  # 0.9.3: solo la pasarela puede hablar «como» la pasarela, y solo a una sesión del edificio
            if a.get("de") != E.pasarela_nombre() or a.get("agente") not in E.agentes_def() or not isinstance(a.get("texto"), str) or not a["texto"].strip():
                return self.rechaza(tenant, m, cid, "Rechazado: mensaje_de pide «de» = la pasarela del edificio, un «agente» existente y un texto.", mid)
        ide = secrets.token_hex(5)
        pedido = {"tipo": skill, "args": a, "via": "a2a", "quien": cid}
        pedido["firma"] = self.firma_pedido(ide, pedido)
        os.makedirs(E.LOCAL_DIR, exist_ok=True)
        ruta = os.path.join(E.LOCAL_DIR, ide + ".pedido")
        t = self.tarea_nueva("", m, cid, "TASK_STATE_SUBMITTED", "Recibida la orden «%s»." % skill, ctx="ctx-admin")
        t["metadata"][EXT_B2]["orden"] = {"habilidad": skill, "id": ide}
        self.almacen.guarda(t, "")
        if mid:
            self.almacen.anota_mensaje(mid, cid, t["id"])
        with open(ruta + ".tmp", "w", encoding="utf-8") as f:
            json.dump(pedido, f, ensure_ascii=False)
        os.replace(ruta + ".tmp", ruta)
        self.almacen.sigue(t["id"], {"tipo": "orden", "ide": ide, "t_envio": time.time(), "cid": cid, "alcance": "admin",
                                     "timeout": self.cfg_num("timeout_orden_s", 600 if skill == "publica_curso" else self.TIMEOUT_ORDEN_S)})
        self.pon_estado(t, "TASK_STATE_WORKING", "Orden «%s» entregada al edificio; la ejecuta su proceso principal." % skill)
        return {"task": t}

    def firma_pedido(self, ide, pedido):
        cuerpo = jcs({"id": ide, "tipo": pedido["tipo"], "args": pedido["args"], "quien": pedido["quien"]})
        return hmac.new(self.token.encode(), cuerpo.encode(), hashlib.sha256).hexdigest()

    # --- CancelTask real
    def cancela(self, p, caller):
        import edificio as E
        if self.SOLO_LECTURA:
            raise ErrorA2A("PermissionDeniedError", "Este edificio es de solo lectura: no se puede cancelar nada")
        self.exige(caller, "escritura")
        with self.escribe:
            ok, motivo = self.pol.puerta()
            if not ok:
                raise ErrorA2A("PermissionDeniedError", "Rechazado por la política: " + motivo)
            t = self.almacen.tarea(str(p.get("id") or "")[:80])
            if not t:
                raise ErrorA2A("TaskNotFoundError", "La tarea no existe", taskId=str(p.get("id") or "")[:60])
            if t["status"]["state"] in ESTADOS_FINALES:
                raise ErrorA2A("TaskNotCancelableError", "La tarea ya terminó (%s)" % t["status"]["state"].replace("TASK_STATE_", ""), taskId=t["id"])
            seg = self.almacen.sigue(t["id"])
            if not seg:
                raise ErrorA2A("TaskNotCancelableError", "Esta tarea no se puede cancelar", taskId=t["id"])
            if seg["tipo"] == "mensaje":
                if self.entregada(seg) or t["status"]["state"] == "TASK_STATE_INPUT_REQUIRED":
                    raise ErrorA2A("TaskNotCancelableError", "La sala ya tiene el mensaje: no se puede retirar", taskId=t["id"])
                if not self.quita_del_buzon(seg["sala"], seg["buzon"]):
                    raise ErrorA2A("TaskNotCancelableError", "No pude retirar el mensaje del buzón (¿ya lo recogió la sala?)", taskId=t["id"])
            else:
                ruta = os.path.join(E.LOCAL_DIR, seg["ide"] + ".pedido")
                try:
                    os.remove(ruta)
                except OSError:
                    raise ErrorA2A("TaskNotCancelableError", "El edificio ya recogió la orden: no se puede retirar", taskId=t["id"])
            self.almacen.sigue(t["id"], borra=True)
            self.pon_estado(t, "TASK_STATE_CANCELED", "Cancelada por el cliente antes de entregarse.")
            return self.recorta(t, None, True)

    @staticmethod
    def quita_del_buzon(sala, ide):
        import edificio as E
        ruta = os.path.join(E.ESTADO, sala + ".buzon.jsonl")
        try:
            with open(ruta, encoding="utf-8") as f:
                ls = f.readlines()
        except OSError:
            return False
        nuevo, quitado = [], False
        for ln in ls:
            try:
                if json.loads(ln).get("id") == ide:
                    quitado = True
                    continue
            except ValueError:
                pass
            nuevo.append(ln)
        if quitado:
            tmp = ruta + ".a2a.tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                f.writelines(nuevo)
            os.replace(tmp, ruta)
        return quitado

    # =================================================================== seguimiento de las tareas vivas (hilo, cada segundo)
    @staticmethod
    def entrega_de(sala, ide):
        import edificio as E
        est = None
        for r in E.lineas(os.path.join(E.ESTADO, sala + ".entrega.jsonl")):
            if isinstance(r, dict) and r.get("id") == ide:
                est = r
        hecho = any(h.get("id") == ide for h in E.lineas(os.path.join(E.ESTADO, sala + ".buzon.jsonl.hecho")))
        return est, hecho

    def nuevas_charla(self, sala, previos):
        import edificio as E
        return [c for c in E.lineas(os.path.join(E.ESTADO, sala + ".charla.jsonl"))
                if c.get("quien") == sala and not c.get("auto") and c.get("uuid") not in previos]

    def entregada(self, seg):
        est, hecho = self.entrega_de(seg["sala"], seg["buzon"])
        return bool(hecho or (est and est.get("estado") in ("entregado", "visto", "contestado")) or self.nuevas_charla(seg["sala"], seg["previos"]))

    def avanza(self):
        import edificio as E
        with self.escribe:
            seguidas = self.almacen.seguidas()
            duenos = {}                                            # sala → la tarea más reciente que espera a esa sala (la que «provocó» el permiso)
            for tid, seg in seguidas:
                if seg.get("tipo") == "mensaje":
                    if seg["sala"] not in duenos or seg["t_envio"] > duenos[seg["sala"]][1]:
                        duenos[seg["sala"]] = (tid, seg["t_envio"])
            for tid, seg in seguidas:
                if seg.get("tipo") == "permiso":                   # las lleva permisos_huerfanos
                    continue
                t = self.almacen.tarea(tid)
                if not t or t["status"]["state"] in ESTADOS_FINALES:
                    self.almacen.sigue(tid, borra=True)
                    continue
                try:
                    if seg["tipo"] == "orden":
                        self.avanza_orden(t, seg)
                    else:
                        self.avanza_mensaje(t, seg, duenos.get(seg["sala"], (None,))[0] == tid)
                except Exception as e:                            # noqa: BLE001 — una tarea rota no para a las demás
                    print("a2a avanza %s: %s %s" % (tid, type(e).__name__, e), flush=True)
            self.permisos_huerfanos(set(duenos))

    def avanza_orden(self, t, seg):
        import edificio as E
        ruta = os.path.join(E.LOCAL_DIR, seg["ide"] + ".respuesta")
        r = E.lee_json(ruta, None)
        if r:
            try:
                os.remove(ruta)
            except OSError:
                pass
            txt = str(r.get("r"))[:1500]
            art = {"artifactId": "resultado", "name": "resultado", "parts": [{"text": txt, "mediaType": "text/plain"}]}
            self.pon_estado(t, "TASK_STATE_COMPLETED" if r.get("ok") else "TASK_STATE_FAILED", ("Hecho: " if r.get("ok") else "No se pudo: ") + txt, artefacto=art)
            self.almacen.sigue(t["id"], borra=True)
        elif time.time() - seg["t_envio"] > seg["timeout"]:
            self.pon_estado(t, "TASK_STATE_FAILED", "El edificio no contestó a la orden en %d s." % seg["timeout"])
            self.almacen.sigue(t["id"], borra=True)

    def avanza_mensaje(self, t, seg, es_dueno):
        import edificio as E
        sala, ahora = seg["sala"], time.time()
        perm = (E.estado_agente(sala) or {}).get("permiso")
        perm = perm if isinstance(perm, dict) and perm.get("firma") else None
        estado = t["status"]["state"]
        if perm and es_dueno:
            if estado != "TASK_STATE_INPUT_REQUIRED" or seg.get("permiso_firma") != perm["firma"]:
                seg["permiso_firma"] = perm["firma"]
                self.almacen.sigue(t["id"], seg)
                self.pon_estado(t, "TASK_STATE_INPUT_REQUIRED", *self.texto_permiso(sala, perm, seg.get("alcance")))
            return
        if estado == "TASK_STATE_INPUT_REQUIRED":                  # el permiso ya no está (lo contestó otro, p. ej. el dueño en su ficha)
            seg["permiso_firma"] = None
            self.almacen.sigue(t["id"], seg)
            self.pon_estado(t, "TASK_STATE_WORKING", "El permiso ya se resolvió; la sala sigue.")
            estado = "TASK_STATE_WORKING"
        ent, hecho = self.entrega_de(sala, seg["buzon"])
        if ent and ent.get("estado") == "retenido" and re.match(r"(demasiados|solo tecleo)", str(ent.get("motivo"))):
            self.pon_estado(t, "TASK_STATE_FAILED", "La sala no aceptó el mensaje: %s." % str(ent.get("motivo"))[:150])
            self.almacen.sigue(t["id"], borra=True)
            return
        nuevas = self.nuevas_charla(sala, seg["previos"])
        sesion = E.tipo_de(sala) == "sesion"
        fin = nuevas and not perm and (hecho or (not sesion and ahora - max(c.get("t", 0) for c in nuevas) >= 2))
        if fin or (nuevas and ahora - seg["t_envio"] > seg["timeout"]):
            txt = "\n".join(POL.limpia(c.get("texto"), 6000) for c in nuevas[-6:])
            txt, vetada = self.pol.filtra_respuesta(seg.get("alcance"), sala, txt)
            art = {"artifactId": "respuesta", "name": "respuesta de " + sala, "parts": [{"text": txt, "mediaType": "text/plain"}],
                   "metadata": {EXT_B2: {"sala": sala, "vetada": vetada}}}
            self.pon_estado(t, "TASK_STATE_COMPLETED", "La sala «%s» ha contestado." % sala, artefacto=art)
            self.almacen.sigue(t["id"], borra=True)
        elif ahora - seg["t_envio"] > seg["timeout"] and not perm:
            self.pon_estado(t, "TASK_STATE_FAILED", "La sala «%s» no contestó en %d s." % (sala, seg["timeout"]))
            self.almacen.sigue(t["id"], borra=True)

    def texto_permiso(self, sala, perm, alcance):
        """(texto legible, DataPart {firma, opciones}). El texto pasa por el veto del que escribió (el grueso, salvo dueño de un edificio de confianza)."""
        ops = [str(o)[:80] for o in perm.get("opciones") or []][:9]
        cuerpo = "La sala «%s» pide permiso: %s\n%s\nOpciones: %s" % (sala, POL.limpia(perm.get("titulo"), 100), POL.limpia(perm.get("texto"), 1400),
                                                                      "; ".join("%d. %s" % (i + 1, o) for i, o in enumerate(ops)))
        if self.pol.veta(cuerpo, self.pol.confianza(alcance)):
            cuerpo = "La sala «%s» pide un permiso (su texto contiene algo vetado y no se reenvía). Opciones: %s" % (
                sala, "; ".join("%d. %s" % (i + 1, o) for i, o in enumerate(ops)))
        return cuerpo, {"firma": perm["firma"], "opciones": ops, "sala": sala}

    def permisos_huerfanos(self, salas_con_tarea):
        """Una sala que pide permiso sin que ninguna tarea nuestra la espere: una tarea «permiso-<sala>» para poder contestarlo desde A2A."""
        import edificio as E
        for sala in sorted(self.salas):
            tid = "permiso-" + sala
            perm = (E.estado_agente(sala) or {}).get("permiso") if sala in E.agentes_def() else None
            perm = perm if isinstance(perm, dict) and perm.get("firma") else None
            t = self.almacen.tarea(tid)
            vivo = t and t["status"]["state"] == "TASK_STATE_INPUT_REQUIRED"
            if perm and sala not in salas_con_tarea:
                seg = self.almacen.sigue(tid) or {}
                if not vivo or seg.get("permiso_firma") != perm["firma"]:
                    t = t or {"id": tid, "contextId": "ctx-" + sala, "history": [], "metadata": {EXT_B2: {"sala": sala, "autor": "edificio"}}}
                    self.pon_estado(t, "TASK_STATE_INPUT_REQUIRED", *self.texto_permiso(sala, perm, "lectura"))
                    self.almacen.sigue(tid, {"tipo": "permiso", "sala": sala, "permiso_firma": perm["firma"], "t_envio": time.time(), "alcance": "lectura",
                                             "buzon": "-", "previos": [], "cid": "edificio", "timeout": 10 ** 9})
            elif vivo and (not perm or sala in salas_con_tarea) and (self.almacen.sigue(tid) or {}).get("tipo") == "permiso":
                self.pon_estado(t, "TASK_STATE_COMPLETED", "El permiso ya se resolvió.")
                self.almacen.sigue(tid, borra=True)

    LECTURAS = ("GetExtendedAgentCard", "GetTask", "ListTasks", "SendMessage")        # SendMessage de lectura = solo «estado» (enviar() lo vuelve a mirar)
    ALCANCES = {"lectura": LECTURAS, "escritura": LECTURAS + ("CancelTask",), "admin": LECTURAS + ("CancelTask",)}   # SEGUNDA cerradura: luna decide el alcance, aquí se vuelve a comprobar

    def atiende_remoto(self, metodo, p, caller, base):
        alcance = (caller or {}).get("alcance")
        if metodo not in self.ALCANCES.get(alcance, ()):
            raise ErrorA2A("PermissionDeniedError", "El alcance «%s» no permite %s" % (str(alcance)[:20], str(metodo)[:30]))
        return self.atiende(metodo, p, base, {"id": str(caller.get("id") or "?")[:40], "alcance": alcance})

    def snapshot(self, base):
        """Instantánea para luna (su caché «stale»): salas B2, tareas de estado y las dos tarjetas firmadas con las URL públicas."""
        with self.cerrojo:
            e = self.ultimo
        pub, ext = self.tarjeta(base, False), self.tarjeta(base, True)
        tareas = [t for t in self.almacen.lista() if t["id"].startswith(("estado-", "puente-"))]   # 0.8.2: también los encargos del puente (edificio «sol»)
        return {"salas": e["salas"], "t": e["t"], "tareas": tareas, "publica": pub, "extendida": ext, "jwks": self.jwks()}

    @staticmethod
    def recorta(t, hist, con_artefactos):
        t = dict(t)
        if not con_artefactos:
            t.pop("artifacts", None)
        if isinstance(hist, int) and "history" in t:
            t["history"] = t["history"][-hist:] if hist > 0 else []
        return t


# ------------------------------------------------------------------ F2: websocket SALIENTE edificio → luna (nuestro transporte, debajo de A2A)
class Relay(threading.Thread):
    """Un solo socket por edificio hacia luna. Luna manda peticiones A2A (t=req) y el edificio las contesta (t=res). No abre puertos."""

    def __init__(self, nucleo, url, ruta_ficha, espera_max=60.0):
        super().__init__(daemon=True)
        self.n, self.url, self.ruta_ficha, self.espera_max = nucleo, url, ruta_ficha, espera_max
        self.sesion = secrets.token_hex(6)
        self.seq_out, self.ultimo_in = 0, 0
        self.anillo = collections.deque(maxlen=256)
        self.luna_sesion = None
        self.base = None
        self.estado = {"conectado": False, "desde": None, "error": "sin conectar", "reconexiones": 0, "peticiones": 0}
        self.ws = None

    def ficha(self):
        try:
            with open(self.ruta_ficha) as f:
                t = f.read().strip()
            return t if t.startswith("ws-") else None
        except OSError:
            return None

    def run(self):
        espera = 1.0
        while True:
            t0 = time.time()
            try:
                self.sesion_ws()
            except (OSError, Cerrado, ValueError, ssl.SSLError) as e:
                self.estado.update(conectado=False, error="%s %s" % (type(e).__name__, str(e)[:80]))
            except Exception as e:                      # noqa: BLE001
                self.estado.update(conectado=False, error="%s %s" % (type(e).__name__, str(e)[:80]))
                print("a2a relay: %s %s" % (type(e).__name__, e), flush=True)
            self.estado["conectado"] = False
            if self.ws is not None:
                self.ws.cierra(1001, "reconectando")
                self.ws = None
            espera = 1.0 if time.time() - t0 > 120 else min(self.espera_max, espera * 2)
            time.sleep(espera * (0.8 + 0.4 * secrets.randbelow(1000) / 1000))
            self.estado["reconexiones"] += 1

    def conecta(self):
        u = urllib.parse.urlsplit(self.url)
        tls = u.scheme == "wss"
        s = socket.create_connection((u.hostname, u.port or (443 if tls else 80)), 15)
        if tls:
            s = ssl.create_default_context().wrap_socket(s, server_hostname=u.hostname)
        clave = base64.b64encode(os.urandom(16)).decode()
        ficha = self.ficha()
        if not ficha:
            s.close()
            raise OSError("falta a2a/ficha_ws")
        s.sendall(("GET %s HTTP/1.1\r\nHost: %s\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Key: %s\r\n"
                   "Sec-WebSocket-Version: 13\r\nSec-WebSocket-Protocol: %s\r\nAuthorization: Bearer %s\r\nUser-Agent: edificio-a2a/%s\r\n\r\n"
                   % (u.path or "/", u.netloc, clave, SUBPROTOCOLO, ficha, VERSION)).encode())
        s.settimeout(15)
        cab = b""
        while b"\r\n\r\n" not in cab:
            d = s.recv(4096)
            if not d:
                raise OSError("luna cerró el handshake")
            cab += d
            if len(cab) > 16384:
                raise OSError("handshake enorme")
        head, resto = cab.split(b"\r\n\r\n", 1)
        lineas_ = head.decode("latin-1").split("\r\n")
        if " 101 " not in lineas_[0] + " ":
            raise OSError("luna contestó: " + lineas_[0][:60])
        h = {x.split(":", 1)[0].strip().lower(): x.split(":", 1)[1].strip() for x in lineas_[1:] if ":" in x}
        if h.get("sec-websocket-accept") != clave_aceptada(clave) or h.get("sec-websocket-protocol") != SUBPROTOCOLO:
            raise OSError("handshake no válido")
        ws = WS(s, True)
        ws.buf = resto
        return ws

    def manda(self, t, con_seq=False, **kw):
        tr = {"v": 1, "t": t}
        tr.update(kw)
        if con_seq:
            self.seq_out += 1
            tr["seq"] = self.seq_out
        txt = json.dumps(tr, ensure_ascii=False, separators=(",", ":"))
        if con_seq:
            self.anillo.append((self.seq_out, txt))
        self.ws.envia(txt)

    def sesion_ws(self):
        self.ws = ws = self.conecta()
        self.manda("ctl", ctl="hola", edificio=self.n.nombre, version=VERSION, protocolo=SUBPROTOCOLO, sesion=self.sesion,
                   ultimo_seq_recibido=self.ultimo_in, luna_sesion=self.luna_sesion, salas=sorted(self.n.salas))
        ws.s.settimeout(15)
        tipo, dato = ws.recibe()
        j = json.loads(dato) if tipo == "texto" else {}
        if j.get("ctl") != "hola_ok":
            raise OSError("luna no dio hola_ok: %s" % (dato if tipo != "texto" else j.get("ctl") or j.get("error")))
        if self.luna_sesion != j.get("luna_sesion"):         # luna se reinició: sus números empiezan de cero
            self.ultimo_in, self.luna_sesion = 0, j.get("luna_sesion")
        self.base = j["base"]
        for seq, txt in list(self.anillo):                    # reenvío de lo que luna no confirmó
            if seq > int(j.get("ultimo_seq_recibido") or 0):
                ws.envia(txt)
        self.estado.update(conectado=True, desde=ahora_iso(), error="")
        ultimo_rx, t_snap, t_ack, huella = time.time(), 0.0, time.time(), None
        while True:
            ahora = time.time()
            if ahora - t_snap >= 30 or t_snap == 0:
                t_snap = ahora
                snap = self.n.snapshot(self.base)
                h = hashlib.sha256(jcs({"p": snap["publica"], "e": snap["extendida"]}).encode()).hexdigest()[:16]
                if h != huella:
                    huella = h
                    self.manda("ctl", ctl="tarjeta", etag=h, publica=snap["publica"], extendida=snap["extendida"], jwks=snap["jwks"])
                self.manda("ctl", ctl="instantanea", hora=snap["t"], salas=snap["salas"], tareas=snap["tareas"], etag=h)
            if ahora - t_ack >= 5:
                t_ack = ahora
                self.manda("ctl", ctl="ack", seq=self.ultimo_in)
            if ahora - ultimo_rx > 45:                         # luna manda ping cada 20 s: 45 s de silencio = conexión muerta
                raise OSError("45 s sin oír a luna")
            if not ws.hay_datos(1.0):
                continue
            ws.s.settimeout(15)
            tipo, dato = ws.recibe()
            ultimo_rx = time.time()
            if tipo == "cierre":
                raise Cerrado(*dato)
            if tipo != "texto":
                continue
            j = json.loads(dato)
            if j.get("t") == "req":
                if int(j.get("seq") or 0) <= self.ultimo_in:      # ya contestada (reenvío tras corte)
                    continue
                self.ultimo_in = int(j["seq"])
                self.estado["peticiones"] += 1
                self.manda("res", True, id=j.get("id"), tenant=j.get("tenant"), a2a=self.contesta(j))
            elif j.get("ctl") == "ack":
                pass
            elif j.get("ctl") == "resync":
                huella, t_snap = None, 0.0

    def contesta(self, j):
        r = j.get("a2a") if isinstance(j.get("a2a"), dict) else {}
        ide = r.get("id")
        try:
            p = dict(r.get("params") or {})
            if j.get("tenant") and not p.get("tenant"):
                p["tenant"] = j["tenant"]
            return {"jsonrpc": "2.0", "id": ide, "result": self.n.atiende_remoto(r.get("method"), p, j.get("caller"), self.base)}
        except ErrorA2A as e:
            return {"jsonrpc": "2.0", "id": ide, "error": e.jsonrpc()}
        except Exception as e:                              # noqa: BLE001
            print("a2a relay contesta: %s %s" % (type(e).__name__, e), flush=True)
            return {"jsonrpc": "2.0", "id": ide, "error": ErrorA2A("InternalError", "Error interno").jsonrpc()}


# ------------------------------------------------------------------ puerta de loopback (HTTP: tarjeta, JSON-RPC, HTTP+JSON)
NUCLEO = None
BASE = ""


class Manejador(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    server_version = "edificio-a2a/" + VERSION

    def log_message(self, *a):
        pass

    def responde(self, codigo, obj, tipo="application/json", extra=None):
        cuerpo = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(codigo)
        self.send_header("Content-Type", tipo)
        self.send_header("Content-Length", str(len(cuerpo)))
        self.send_header("A2A-Version", PROTOCOLO)
        for k, v in (extra or {}).items():
            self.send_header(k, v)
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(cuerpo)

    def autentica(self):
        a = self.headers.get("Authorization", "")
        return a.startswith("Bearer ") and hmac.compare_digest(a[7:].strip().encode(), NUCLEO.token.encode())

    def no_autorizado(self, rest=True, ide=None):
        e = ErrorA2A("UnauthenticatedError", "Hace falta el Bearer del edificio")
        cuerpo = e.rest() if rest else {"jsonrpc": "2.0", "id": ide, "error": e.jsonrpc()}
        self.responde(401, cuerpo, extra={"WWW-Authenticate": 'Bearer realm="edificio-a2a"'})

    def cuerpo_json(self):
        n = int(self.headers.get("Content-Length") or 0)
        if n > LIMITE_CUERPO:
            raise ErrorA2A("InvalidRequestError", "cuerpo demasiado grande")
        if n == 0:
            return {}
        try:
            return json.loads(self.rfile.read(n).decode("utf-8"))
        except ValueError:
            raise ErrorA2A("InvalidRequestError", "JSON no válido")

    def do_HEAD(self):
        self.do_GET()

    def do_GET(self):
        u = urllib.parse.urlsplit(self.path)
        ruta, q = u.path, {k: v[-1] for k, v in urllib.parse.parse_qs(u.query).items()}
        try:
            if ruta == "/.well-known/agent-card.json":
                return self.responde(200, NUCLEO.tarjeta(BASE, False), extra={"Cache-Control": "public, max-age=60"})
            if ruta == "/.well-known/jwks.json":
                return self.responde(200, NUCLEO.jwks(), extra={"Cache-Control": "public, max-age=300"})
            if ruta == "/salud":
                return self.responde(200, {"ok": True, "version": VERSION, "t": int(time.time()),
                                           "relay": NUCLEO.relay.estado if NUCLEO.relay else None})
            if ruta.startswith("/rest/"):
                if not self.autentica():
                    return self.no_autorizado()
                r = ruta[5:]
                if r == "/extendedAgentCard":
                    return self.responde(200, NUCLEO.atiende("GetExtendedAgentCard", q, BASE), "application/a2a+json")
                if r == "/tasks":
                    return self.responde(200, NUCLEO.atiende("ListTasks", q, BASE), "application/a2a+json")
                if r.startswith("/tasks/") and not r.endswith((":cancel", ":subscribe")):
                    return self.responde(200, NUCLEO.atiende("GetTask", dict(q, id=urllib.parse.unquote(r[7:])), BASE), "application/a2a+json")
            self.responde(404, ErrorA2A("MethodNotFoundError", "No existe esa ruta").rest())
        except ErrorA2A as e:
            self.responde(e.http, e.rest(), "application/a2a+json")

    def do_POST(self):
        ruta = urllib.parse.urlsplit(self.path).path
        try:
            if ruta == "/rpc":
                try:
                    j = self.cuerpo_json()
                except ErrorA2A as e:
                    return self.responde(200, {"jsonrpc": "2.0", "id": None, "error": dict(e.jsonrpc(), code=-32700 if "JSON" in e.mensaje else -32600)})
                ide = j.get("id") if isinstance(j, dict) else None
                if not self.autentica():
                    return self.no_autorizado(False, ide)
                if not isinstance(j, dict) or j.get("jsonrpc") != "2.0" or not isinstance(j.get("method"), str):
                    return self.responde(200, {"jsonrpc": "2.0", "id": ide, "error": ErrorA2A("InvalidRequestError", "Request payload validation error").jsonrpc()})
                try:
                    return self.responde(200, {"jsonrpc": "2.0", "id": ide, "result": NUCLEO.atiende(j["method"], j.get("params"), BASE)})
                except ErrorA2A as e:
                    return self.responde(200, {"jsonrpc": "2.0", "id": ide, "error": e.jsonrpc()})
            if ruta.startswith("/rest/"):
                if not self.autentica():
                    return self.no_autorizado()
                r = ruta[5:]
                if r == "/message:send":
                    return self.responde(200, NUCLEO.atiende("SendMessage", self.cuerpo_json(), BASE), "application/a2a+json")
                if r == "/message:stream":
                    NUCLEO.atiende("SendStreamingMessage", {}, BASE)
                if r.startswith("/tasks/") and r.endswith(":cancel"):
                    return self.responde(200, NUCLEO.atiende("CancelTask", {"id": urllib.parse.unquote(r[7:-7])}, BASE), "application/a2a+json")
            self.responde(404, ErrorA2A("MethodNotFoundError", "No existe esa ruta").rest())
        except ErrorA2A as e:
            self.responde(e.http, e.rest(), "application/a2a+json")
        except Exception as e:                          # noqa: BLE001
            print("a2a: %s %s" % (type(e).__name__, e), flush=True)
            self.responde(500, ErrorA2A("InternalError", "Error interno").rest())


def servir():
    global NUCLEO, BASE
    import edificio as E
    cfg = E.lee_json(E.CONFIG, {})
    ca = cfg.get("a2a") or {}
    puerto = ca.get("puerto") if isinstance(ca.get("puerto"), int) else 8890
    NUCLEO = Nucleo(cfg)
    BASE = "http://127.0.0.1:%d" % puerto
    ws = ca.get("ws")
    if isinstance(ws, dict) and ws.get("activo") is True and str(ws.get("url", "")).startswith(("wss://", "ws://127.0.0.1")):
        NUCLEO.relay = Relay(NUCLEO, ws["url"], os.path.join(DIR, "ficha_ws"),
                             float(ws["espera_max_s"]) if isinstance(ws.get("espera_max_s"), (int, float)) and 1 <= ws["espera_max_s"] <= 60 else 60.0)
        NUCLEO.relay.start()
    srv = ThreadingHTTPServer(("127.0.0.1", puerto), Manejador)      # SOLO loopback
    srv.daemon_threads = True
    _escribe600(os.path.join(DIR, "a2a.pid"), json.dumps({"pid": os.getpid(), "puerto": puerto, "version": VERSION}))
    padre = os.getppid()

    def bucle():
        while True:
            time.sleep(REFRESCO_S)
            if os.getppid() != padre:                  # el edificio murió o se reinició: este hijo no se queda huérfano
                os._exit(0)
            try:
                NUCLEO.refresca()
            except Exception as e:                      # noqa: BLE001
                print("a2a refresca: %s %s" % (type(e).__name__, e), flush=True)
    threading.Thread(target=bucle, daemon=True).start()

    def sigue_tareas():
        while True:
            time.sleep(1)
            try:
                NUCLEO.avanza()
            except Exception as e:                      # noqa: BLE001
                print("a2a sigue_tareas: %s %s" % (type(e).__name__, e), flush=True)
    threading.Thread(target=sigue_tareas, daemon=True).start()
    print("a2a %s en %s (solo loopback; lectura, escritura con política%s)" % (VERSION, BASE, "; websocket saliente a luna" if NUCLEO.relay else ""), flush=True)
    srv.serve_forever()


if __name__ == "__main__":
    a = sys.argv[1:]
    if a == ["servir"]:
        servir()
    elif a == ["tarjeta"]:
        import edificio as E
        NUCLEO = Nucleo(E.lee_json(E.CONFIG, {}))
        print(json.dumps(NUCLEO.tarjeta("http://127.0.0.1:8890", True), ensure_ascii=False, indent=1))
    elif a == ["token"]:
        print(token_local())
    else:
        print(__doc__)
