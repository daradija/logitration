"""Piezas comunes de A2A que usan el edificio (a2a.py) y luna (a2a_luna.py): errores A2A, hora ISO y un códec mínimo de WebSocket
(RFC 6455) en Python estándar. Sin librerías. Solo lo que usamos: texto, ping/pong, cierre, fragmentos al recibir, máscara
cliente→servidor, límite de trama, sin compresión ni extensiones. Subprotocolo propio: a2a-relay.v1 (transporte privado DEBAJO de A2A)."""
import base64
import hashlib
import os
import socket
import struct
import threading
import time

SUBPROTOCOLO = "a2a-relay.v1"
GUID = "258EAFA5-E914-47DA-95CA-C5AB0DC85B11"
LIMITE_TRAMA = 1 << 20                       # 1 MiB
OP_CONT, OP_TEXTO, OP_BINARIO, OP_CIERRE, OP_PING, OP_PONG = 0, 1, 2, 8, 9, 10


def ahora_iso():
    t = time.time()
    return time.strftime("%Y-%m-%dT%H:%M:%S", time.gmtime(t)) + ".%03dZ" % int((t % 1) * 1000)


class ErrorA2A(Exception):
    """Errores A2A con su código JSON-RPC y su estado HTTP (§5.4 de la especificación 1.0)."""
    ERRORES = {"TaskNotFoundError": (-32001, 404), "TaskNotCancelableError": (-32002, 400), "PushNotificationNotSupportedError": (-32003, 400),
               "UnsupportedOperationError": (-32004, 400), "ContentTypeNotSupportedError": (-32005, 400),
               "ExtendedAgentCardNotConfiguredError": (-32007, 400), "ExtensionSupportRequiredError": (-32008, 400), "VersionNotSupportedError": (-32009, 400),
               "InvalidParamsError": (-32602, 400), "MethodNotFoundError": (-32601, 404), "InvalidRequestError": (-32600, 400),
               "InternalError": (-32603, 500), "UnauthenticatedError": (-32001, 401), "PermissionDeniedError": (-32004, 403),
               "EdificioDesconectadoError": (-32010, 503), "EdificioNoRespondeError": (-32011, 504)}
    STATUS = {400: "INVALID_ARGUMENT", 401: "UNAUTHENTICATED", 403: "PERMISSION_DENIED", 404: "NOT_FOUND", 500: "INTERNAL",
              503: "UNAVAILABLE", 504: "DEADLINE_EXCEEDED"}

    def __init__(self, tipo, mensaje, **meta):
        super().__init__(mensaje)
        self.tipo, self.mensaje, self.meta = tipo, mensaje, meta
        self.codigo, self.http = self.ERRORES[tipo]

    def _razon(self):
        return "".join("_" + c if c.isupper() else c for c in self.tipo[:-5]).lstrip("_").upper()

    def jsonrpc(self):
        return {"code": self.codigo, "message": self.mensaje,
                "data": [{"@type": "type.googleapis.com/google.rpc.ErrorInfo", "reason": self._razon(), "domain": "a2a-protocol.org",
                          "metadata": dict(self.meta, timestamp=ahora_iso())}]}

    def rest(self):
        return {"error": {"code": self.http, "status": self.STATUS.get(self.http, "UNKNOWN"), "message": self.mensaje,
                          "details": [{"@type": "type.googleapis.com/google.rpc.ErrorInfo", "reason": self._razon(), "domain": "a2a-protocol.org",
                                       "metadata": dict(self.meta, timestamp=ahora_iso())}]}}

    @classmethod
    def de_jsonrpc(cls, e):
        """Reconstruye un ErrorA2A desde un error JSON-RPC recibido (luna lo hace con lo que contesta el edificio)."""
        for tipo, (cod, _) in cls.ERRORES.items():
            if cod == e.get("code"):
                x = cls(tipo, str(e.get("message") or tipo))
                return x
        return cls("InternalError", str(e.get("message") or "error"))


# ------------------------------------------------------------------ WebSocket mínimo
def clave_aceptada(clave):
    return base64.b64encode(hashlib.sha1((clave + GUID).encode("ascii")).digest()).decode("ascii")


class Cerrado(Exception):
    def __init__(self, codigo=1006, motivo=""):
        super().__init__("%s %s" % (codigo, motivo))
        self.codigo, self.motivo = codigo, motivo


class WS:
    """Un websocket ya negociado sobre un socket. es_cliente: los marcos que ENVÍA llevan máscara. Un solo lector; envíos con cerrojo."""

    def __init__(self, sock, es_cliente):
        self.s, self.cli = sock, es_cliente
        self.cerrojo = threading.Lock()
        self.cerrado = False
        self.buf = b""

    def hay_datos(self, espera):
        """¿Hay algo que leer ya (o llega en `espera` s)? Se mira ANTES de recibir para no cortar un marco a medias por un timeout."""
        if self.buf or (hasattr(self.s, "pending") and self.s.pending()):
            return True
        import select
        return bool(select.select([self.s], [], [], espera)[0])

    def _exacto(self, n):
        while len(self.buf) < n:
            d = self.s.recv(65536)
            if not d:
                raise Cerrado(1006, "conexión cerrada")
            self.buf += d
        r, self.buf = self.buf[:n], self.buf[n:]
        return r

    def _marco(self):
        b1, b2 = self._exacto(2)
        fin, op, enmascarado, n = bool(b1 & 0x80), b1 & 0x0F, bool(b2 & 0x80), b2 & 0x7F
        if b1 & 0x70:
            raise Cerrado(1002, "bits reservados")
        if n == 126:
            n = struct.unpack(">H", self._exacto(2))[0]
        elif n == 127:
            n = struct.unpack(">Q", self._exacto(8))[0]
        if n > LIMITE_TRAMA:
            raise Cerrado(1009, "trama demasiado grande")
        if enmascarado == self.cli:                  # el servidor NO enmascara; el cliente SÍ
            raise Cerrado(1002, "máscara incorrecta")
        m = self._exacto(4) if enmascarado else b""
        d = self._exacto(n) if n else b""
        if enmascarado:
            d = bytes(x ^ m[i & 3] for i, x in enumerate(d))
        return fin, op, d

    def recibe(self):
        """('texto', str) | ('ping', bytes) | ('pong', bytes) | ('cierre', (codigo, motivo)). Lanza socket.timeout si no llega nada."""
        trozos, op0 = [], None
        while True:
            fin, op, d = self._marco()
            if op >= 8:
                if not fin or len(d) > 125:
                    raise Cerrado(1002, "control mal formado")
                if op == OP_CIERRE:
                    cod = struct.unpack(">H", d[:2])[0] if len(d) >= 2 else 1005
                    return ("cierre", (cod, d[2:].decode("utf-8", "replace")))
                if op == OP_PING:
                    try:
                        self.marco(OP_PONG, d)
                    except OSError:
                        pass
                    return ("ping", d)
                if op == OP_PONG:
                    return ("pong", d)
                raise Cerrado(1002, "opcode desconocido")
            if op == OP_CONT:
                if op0 is None:
                    raise Cerrado(1002, "continuación sin inicio")
            elif op0 is not None:
                raise Cerrado(1002, "mensaje nuevo sin acabar el anterior")
            else:
                op0 = op
            trozos.append(d)
            if sum(len(x) for x in trozos) > LIMITE_TRAMA:
                raise Cerrado(1009, "trama demasiado grande")
            if fin:
                if op0 != OP_TEXTO:
                    raise Cerrado(1003, "solo texto")
                try:
                    return ("texto", b"".join(trozos).decode("utf-8"))
                except UnicodeDecodeError:
                    raise Cerrado(1007, "UTF-8 no válido")

    def marco(self, op, datos=b""):
        n = len(datos)
        cab = bytes([0x80 | op])
        mask = 0x80 if self.cli else 0
        cab += bytes([mask | n]) if n < 126 else (bytes([mask | 126]) + struct.pack(">H", n) if n < 65536 else bytes([mask | 127]) + struct.pack(">Q", n))
        if self.cli:
            m = os.urandom(4)
            datos = bytes(x ^ m[i & 3] for i, x in enumerate(datos))
            cab += m
        with self.cerrojo:
            self.s.sendall(cab + datos)

    def envia(self, texto):
        d = texto.encode("utf-8")
        if len(d) > LIMITE_TRAMA:
            raise ValueError("trama demasiado grande")
        self.marco(OP_TEXTO, d)

    def ping(self):
        self.marco(OP_PING, b"")

    def cierra(self, codigo=1000, motivo=""):
        if self.cerrado:
            return
        self.cerrado = True
        try:
            self.marco(OP_CIERRE, struct.pack(">H", codigo) + motivo.encode("utf-8")[:100])
        except OSError:
            pass
        try:
            self.s.shutdown(socket.SHUT_RDWR)
        except OSError:
            pass
        try:
            self.s.close()
        except OSError:
            pass
