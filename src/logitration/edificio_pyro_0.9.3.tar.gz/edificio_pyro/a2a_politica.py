"""Capa de POLÍTICA del servidor A2A del edificio (0.8.1, F3). Va POR DELANTE de toda habilidad de escritura (mensaje a una sala, contestar un
permiso, órdenes de admin, cancelar) y vale para TODAS las puertas: loopback y relé de luna entran por la misma función (a2a.Nucleo.atiende).

Es el PORTE de la política de la pasarela (build/pasarela/pasarela.py + consignas/<sobre>.*), sin la IA:
  · RED DE SEGURIDAD de regex (consignas/<sobre>.veto, y <sobre>.david.veto = solo secretos para el dueño): los mismos ficheros, el mismo
    algoritmo que pasarela.vetos(); sin lista ⇒ todo vetado. Se aplica al texto que ENTRA y a la respuesta que SALE.
  · CONSIGNA: consignas/<sobre>.txt es el texto de la pasarela para su IA. Sin ese fichero: «Sin consigna: niega todo», como la pasarela.
    La parte determinista de la política de A2A está en <sobre>.a2a (líneas «salas: a, b | *» y «tope_texto: n»); sin él, ninguna sala admite escritura.
  · CONFIANZA = ("agua",): en un edificio de confianza, quien llega con alcance «admin» es el dueño (como David desde sol): veto de solo secretos.
    Con cualquier otro alcance rige el veto grueso. El modo «bypass» de crear_sesion solo se da en confianza.
  · ACCIONES: la lista cerrada de órdenes de la pasarela con sus argumentos permitidos y sus validaciones (prepara_accion).
  · IA: la pasarela usa un `claude -p` sin herramientas para CONTESTAR PREGUNTAS. Aquí no hay pregunta que contestar (escribir a una sala o dar una
    orden cerrada no pasa por ningún modelo): no se porta. Lo que decide es código determinista.
  · «niega todo»: config.json "a2a": {"politica": "niega_todo"} (o el fichero a2a/politica/NIEGA): ninguna escritura entra por ninguna puerta.
Solo stdlib. La batería prueba_a2a/bateria_politica.py compara este módulo con la pasarela caso por caso.
"""
import json
import os
import re

CONFIANZA = ("agua",)                                        # 29-10 (orden de David): agua es entorno de confianza para David
NEGADO = "No puedo contestar eso: la consigna de %s no lo permite."
AGENTE_OK = re.compile(r"^[a-z][a-z0-9_-]{0,23}$")
ACCIONES = {          # tipo de orden → (argumentos permitidos, desde qué versión del edificio): la misma tabla que pasarela.ACCIONES
    "crear_agente": (("nombre", "sala", "tarea"), (0, 5)),
    "arrancar_agente": (("nombre",), (0, 5)),
    "parar_agente": (("nombre",), (0, 5)),
    "borrar_agente": (("nombre",), (0, 5)),
    "mover": (("nombre", "sala"), (0, 5)),
    "renombrar_sala": (("sala", "texto"), (0, 5)),
    "emblema": (("nombre", "emoji"), (0, 5)),
    "mensaje": (("nombre", "texto"), (0, 5)),
    "crear_sesion": (("nombre", "sala", "tarea", "modo"), (0, 6, 2)),
}
# Lo que A2A añade a la lista de la pasarela (las órdenes cerradas que la pasarela no daba): sus argumentos, validados por el propio edificio.
EXTRA_ADMIN = {"publica_curso": ("curso", "carpeta"), "deposita": ("paquete", "envio", "inicio", "ficheros"),
               "mensaje_de": ("agente", "de", "texto"),      # 0.9.3: la pasarela contesta a una sesión (sustituye a la orden del latido)
               "acusa_pasarela": ("ids",)}                   # 0.9.3: luna acusa los mensajes de sesiones a la pasarela que ya recogió (se retiran de la salida)
SKILLS_ADMIN = tuple(ACCIONES) + tuple(EXTRA_ADMIN)


def limpia(s, n):
    return re.sub(r"[\x00-\x08\x0b-\x1f\x7f]", "", str(s if s is not None else "")).strip()[:n]


def _ver_tupla(v):
    try:
        return tuple(int(x) for x in str(v).split(".")[:3])
    except ValueError:
        return (0,)


class Politica:
    """sobre = el nombre del edificio (agua); carpeta = donde están <sobre>.txt, <sobre>.veto, <sobre>.david.veto y <sobre>.a2a."""

    def __init__(self, carpeta, sobre, cfg_fn=None):
        self.carpeta, self.sobre, self.cfg_fn = carpeta, sobre, cfg_fn
        self._cache = {}

    def _ruta(self, ext):
        return os.path.join(self.carpeta, self.sobre + ext)

    # --- ficheros (se releen si cambian: la política se edita en caliente)
    def _lee(self, ext):
        r = self._ruta(ext)
        try:
            mt = os.stat(r).st_mtime
        except OSError:
            self._cache.pop(ext, None)
            return None
        c = self._cache.get(ext)
        if not c or c[0] != mt:
            with open(r, encoding="utf-8") as f:
                c = (mt, f.read())
            self._cache[ext] = c
        return c[1]

    def consigna(self):
        t = self._lee(".txt")
        return t if t is not None else "Sin consigna: niega todo."

    def hay_consigna(self):
        return self._lee(".txt") is not None

    def vetos(self, confianza=False):
        """Igual que pasarela.vetos(): confianza → <sobre>.david.veto (solo secretos) si existe, si no <sobre>.veto; sin lista, todo vetado."""
        ext = ".david.veto" if confianza and self._lee(".david.veto") is not None else ".veto"
        t = self._lee(ext)
        ls = [x.strip() for x in (t or "").splitlines()]
        return [re.compile(x, re.I) for x in ls if x and not x.startswith("#")] or [re.compile(r".", re.S)]

    def veta(self, texto, confianza=False):
        return any(v.search(texto) for v in self.vetos(confianza))

    def directivas(self):
        """<sobre>.a2a → {"salas": set|None('*')|vacío, "tope_texto": int}. Sin fichero: nada se puede escribir."""
        t = self._lee(".a2a")
        d = {"salas": set(), "todas": False, "tope_texto": 2000}
        for ln in (t or "").splitlines():
            ln = ln.split("#", 1)[0].strip()
            if ":" not in ln:
                continue
            k, v = (x.strip() for x in ln.split(":", 1))
            if k == "salas":
                if v == "*":
                    d["todas"] = True
                else:
                    d["salas"] = {x.strip() for x in v.split(",") if x.strip()}
            elif k == "tope_texto" and v.isdigit():
                d["tope_texto"] = max(1, min(int(v), 4000))
        return d

    # --- el interruptor general
    def niega_todo(self):
        if os.path.exists(os.path.join(self.carpeta, "NIEGA")):
            return True
        try:
            c = (self.cfg_fn() or {}).get("a2a") if self.cfg_fn else None
        except Exception:                                    # noqa: BLE001 — si no se puede leer la config, se niega
            return True
        return isinstance(c, dict) and c.get("politica") == "niega_todo"

    def confianza(self, alcance):
        """La pasarela: confianza = sobre en CONFIANZA y origen sol_ui (David). Aquí: edificio de confianza y alcance admin (el dueño)."""
        return self.sobre in CONFIANZA and alcance == "admin"

    # --- decisiones
    def puerta(self):
        """(True, "") o (False, motivo): lo que va antes de mirar nada más."""
        if self.niega_todo():
            return False, "la política del edificio está en «niega todo»"
        if not self.hay_consigna():
            return False, "Sin consigna: niega todo."
        return True, ""

    def autoriza_envio(self, alcance, sala, texto):
        """Un SendMessage de texto a una sala. → (True, "") o (False, motivo)."""
        ok, m = self.puerta()
        if not ok:
            return False, m
        d = self.directivas()
        if not (d["todas"] or sala in d["salas"]):
            return False, NEGADO % self.sobre
        if len(texto) > d["tope_texto"]:
            return False, "el mensaje pasa de %d caracteres" % d["tope_texto"]
        if self.veta(texto, self.confianza(alcance)):
            return False, "el mensaje contiene algo vetado"
        return True, ""

    def filtra_respuesta(self, alcance, de, texto):
        """La respuesta de la sala antes de salir. → (texto, vetada). Mismo texto y mismo criterio que pasarela.espera_agente."""
        if self.veta(texto, self.confianza(alcance)):
            return "%s ha contestado, pero la respuesta lleva algo que parece una clave y no la reenvío." % de, True
        return texto, False

    @staticmethod
    def filtra_args(tipo, bruto, nombre):
        """Los argumentos de la ORDEN del edificio (su vocabulario: nombre/sala/tarea/modo/texto/emoji…), solo los permitidos y con el nombre normalizado."""
        bruto = bruto if isinstance(bruto, dict) else {}
        permitidos = ACCIONES[tipo][0] if tipo in ACCIONES else EXTRA_ADMIN[tipo]
        a = {k: v for k, v in bruto.items() if k in permitidos}
        if nombre and "nombre" in permitidos:
            a["nombre"] = nombre
        return a

    def prepara_accion(self, tipo, bruto, ags, plano, pas, version):
        """Porte de pasarela.prepara_accion sin red. ags = {nombre: {"pasarela":…, "virtual":…}}, plano = {"sala": nombre}, pas = nombre de la pasarela.
        → (datos, nombre) o ValueError. El edificio vuelve a validar después (sus ORDENES); esto es lo que añade la política."""
        if tipo in EXTRA_ADMIN:
            a = {k: v for k, v in (bruto if isinstance(bruto, dict) else {}).items() if k in EXTRA_ADMIN[tipo]}
            return a, None
        if tipo not in ACCIONES:
            raise ValueError("esa orden no está entre las que puedo dar en %s" % self.sobre)
        permitidos, desde = ACCIONES[tipo]
        bruto = bruto if isinstance(bruto, dict) else {}
        a = {k: v for k, v in bruto.items() if k in permitidos}
        if "nombre" not in a and bruto.get("agente"):
            a["nombre"] = bruto["agente"]
        if _ver_tupla(version) < desde:
            raise ValueError("el edificio de %s es de la versión %s y «%s» pide la %s" % (self.sobre, version, tipo, ".".join(map(str, desde))))
        datos, nombre = {}, None
        if tipo != "renombrar_sala":
            nombre = str(a.get("nombre") or "").strip().lower()
            if not AGENTE_OK.match(nombre):
                raise ValueError("el nombre del agente no es válido (minúsculas, cifras, - o _, empieza por letra, hasta 24)")
            if nombre in (pas, "mantenedor") or (ags.get(nombre) or {}).get("pasarela") or (ags.get(nombre) or {}).get("virtual"):
                raise ValueError("«%s» es del propio edificio (la pasarela o el mantenedor): no lo toco" % nombre)
            if tipo in ("crear_agente", "crear_sesion"):
                if nombre in ags:
                    raise ValueError("ya existe un agente llamado %s" % nombre)
            elif nombre not in ags:
                raise ValueError("no hay ningún agente llamado %s (hay: %s)" % (nombre, ", ".join(sorted(k for k in ags if k != pas)) or "ninguno"))
        if tipo in ("crear_agente", "arrancar_agente", "crear_sesion"):
            datos["nombre"] = nombre
        elif tipo == "mensaje":
            datos = {"sid": nombre, "texto": limpia(a.get("texto"), 4000)}
            if not datos["texto"]:
                raise ValueError("falta el texto del mensaje")
        elif tipo == "parar_agente":
            datos = {"sid": nombre}
        elif tipo == "borrar_agente":
            datos = {"nombre": nombre}
        elif tipo == "mover":
            datos = {"nombre": nombre}
        elif tipo == "emblema":
            datos = {"nombre": nombre, "emoji": limpia(a.get("emoji"), 8)}
        if "sala" in permitidos:
            s = a.get("sala")
            if s is not None and s != "":
                if isinstance(s, str) and s.strip().isdigit():
                    s = int(s)
                if not isinstance(s, int) or isinstance(s, bool) or not 0 <= s <= 39:
                    raise ValueError("la sala no es válida (número de 0 a 39)")
                ocupada = plano.get(str(s))
                if tipo in ("crear_agente", "crear_sesion", "mover") and ocupada and ocupada != nombre:
                    raise ValueError("la sala %d está ocupada por %s" % (s, ocupada))
                datos["sala"] = s
            elif tipo in ("mover", "renombrar_sala"):
                raise ValueError("falta la sala")
        if tipo in ("crear_agente", "crear_sesion") and a.get("tarea"):
            datos["tarea"] = limpia(a.get("tarea"), 200)
        if tipo == "crear_sesion" and a.get("modo") not in (None, ""):
            if a.get("modo") not in ("default", "bypass"):
                raise ValueError("el modo de permisos es default o bypass")
            if a.get("modo") == "bypass":
                if self.sobre not in CONFIANZA:
                    raise ValueError("el modo bypass solo se da en un entorno de confianza (agua), no en %s" % self.sobre)
                if _ver_tupla(version) < (0, 6, 8):
                    raise ValueError("el edificio de %s es de la versión %s y el modo bypass pide la 0.6.8" % (self.sobre, version))
                datos["modo"] = "bypass"
        if tipo == "renombrar_sala":
            datos["texto"] = limpia(a.get("texto"), 60)
            if plano.get(str(datos.get("sala"))) == pas:
                raise ValueError("esa sala es la de la pasarela")
        return datos, nombre
