"""agente.py — agente de PRUEBA del edificio a escala: simula trabajo, habla y escribe su estado. Sin IA ni red.

    python3 agente.py <nombre> <carpeta_estado> [otro_agente] [tarea]

Cada pocos segundos hace una cosa (de una lista fija) y la cuenta:
  <carpeta>/<nombre>.json          su estado: {estado, que, herramienta, pregunta, ayudante, hechas, t}
                                   estado: «trabaja» (verde), «espera» (te pregunta algo) o «descansa» (amarillo)
  <carpeta>/<nombre>.charla.jsonl  lo que dice (se ve en su bocadillo grande al pulsar su habitación)
  <carpeta>/<nombre>.buzon.jsonl   lo que le escriben (tú desde la página, o el otro agente); lo contesta con frases fijas
  <carpeta>/<nombre>.entrega.jsonl {id, estado, motivo}: el estado de cada mensaje tuyo (visto → contestado)
Gasta lo mínimo: duerme casi todo el tiempo. Se para con SIGTERM (lo para edificio.py).
"""
import json
import os
import random
import signal
import sys
import time

DE_USUARIO = ("usuario", "enlace", "claude", "David")   # quien escribe desde PyRoboAdvisor (autor firmado por el servidor; «David» solo por los ficheros viejos)

TAREAS = {   # (lo que hace, lo que dice al acabar)
    "contador": [("cuenta las piezas del almacén", "He contado {n} piezas en la estantería {L}."),
                 ("suma la caja del día", "La caja de hoy suma {n} €."),
                 ("repasa el inventario", "Inventario repasado: faltan {k} tornillos."),
                 ("apunta una entrada en el libro", "Apuntada la entrada {n} en el libro.")],
    "lector": [("lee el periódico", "En el periódico de hoy hay {k} noticias de bolsa."),
               ("ordena la estantería", "Estantería {L} ordenada por autor."),
               ("resume un capítulo", "Resumido el capítulo {k}: va de paciencia."),
               ("busca una cita", "Cita encontrada en la página {n}.")],
}
PREGUNTAS = {"contador": "¿Cuento también el almacén de abajo?", "lector": "¿Te leo el resumen del capítulo?"}
AVISOS = {"contador": "{otro}, te paso la cuenta: {n} piezas. ¿Lo apuntas en el libro?",
          "lector": "{otro}, he encontrado el recibo que buscabas en la página {n}."}


def frase(f, otro=""):
    return f.format(n=random.randint(12, 480), k=random.randint(2, 9), L=random.choice("ABCDE"), otro=otro.capitalize())


def lineas(ruta):
    try:
        with open(ruta, encoding="utf-8") as f:
            return [json.loads(x) for x in f if x.strip()]
    except (OSError, ValueError):
        return []


def apunta(ruta, d, tope=300):
    """Añade una línea; si el fichero pasa de 2×tope líneas, se queda con las últimas tope (nunca crece sin fin)."""
    with open(ruta, "a", encoding="utf-8") as f:
        f.write(json.dumps(d, ensure_ascii=False) + "\n")
    ls = lineas(ruta)
    if len(ls) > 2 * tope:
        tmp = ruta + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            f.writelines(json.dumps(x, ensure_ascii=False) + "\n" for x in ls[-tope:])
        os.replace(tmp, ruta)


def main():
    nombre, carpeta = sys.argv[1], sys.argv[2]
    otro = sys.argv[3] if len(sys.argv) > 3 else ""
    tarea = (sys.argv[4] if len(sys.argv) > 4 else "").strip()[:200]
    padre = os.getppid()
    os.makedirs(carpeta, exist_ok=True)
    charla, buzon = os.path.join(carpeta, nombre + ".charla.jsonl"), os.path.join(carpeta, nombre + ".buzon.jsonl")
    tareas = TAREAS.get(nombre, [("hace su trabajo", "Trabajo hecho.")])
    if tarea:                                       # agente creado desde la interfaz: simula avanzar en SU tarea
        corta = tarea[:60]
        f = corta.replace("{", "{{").replace("}", "}}")   # el texto va dentro de frases con .format
        tareas = [("avanza en: " + corta, "Avance en «" + f + "»: {k} de 9 pasos hechos."),
                  ("revisa lo hecho de: " + corta, "Revisado lo de «" + f + "»: {n} comprobaciones, todo en orden."),
                  ("prepara el siguiente paso de: " + corta, "Siguiente paso de «" + f + "» preparado.")]
    vivo = [True]
    signal.signal(signal.SIGTERM, lambda *_: vivo.__setitem__(0, False))
    st = {"estado": "trabaja", "que": "", "herramienta": "", "pregunta": "", "ayudante": 0, "hechas": 0}
    entrega = os.path.join(carpeta, nombre + ".entrega.jsonl")
    vistos = {x.get("id") for x in lineas(buzon)}   # lo que ya estaba al arrancar no se vuelve a contestar
    pregunta_t = 0

    def di(texto, auto=False):
        apunta(charla, {"quien": nombre, "texto": texto, "t": time.time(), "uuid": "%x" % random.getrandbits(48),
                        **({"auto": True} if auto else {})})

    if not lineas(charla):
        di("Hola, soy el %s%s. Pulsa mi habitación para ver lo que hago y escríbeme abajo si quieres."
           % (nombre, (" y mi tarea es: " + tarea) if tarea else ""))
    while vivo[0] and os.getppid() == padre:        # si el proceso que me lanzó desaparece, me voy
        nuevos = [x for x in lineas(buzon) if x.get("id") not in vistos]
        st.update(ayudante=max(0, st["ayudante"] - 1), herramienta="")
        if nuevos:                                  # primero, contestar
            for m in nuevos:
                vistos.add(m.get("id"))
                if m.get("de") in DE_USUARIO:       # tú, desde la interfaz
                    apunta(entrega, {"id": m.get("id"), "estado": "visto", "t": time.time()}, 200)
                    if m.get("tipo") == "permiso":  # una respuesta a un permiso (los agentes de prueba no piden ninguno)
                        di("Recibido tu permiso (opción %s)." % m.get("n"))
                    elif st["pregunta"]:
                        di("Gracias por contestar («%s»). Sigo con eso." % m.get("texto", "")[:200])
                        st["pregunta"] = ""
                    else:
                        di("Recibido: «%s». Soy un agente de prueba sin IA: lo apunto y sigo con lo mío."
                           % m.get("texto", "")[:200])
                    apunta(buzon + ".hecho", {"id": m.get("id"), "t": time.time()})
                else:                               # el otro agente
                    di("%s me escribe: «%s». Hecho, lo apunto." % (m.get("de"), m.get("texto", "")[:200]))
            st.update(estado="trabaja", que="contesta un mensaje", herramienta="Write")
        elif st["pregunta"] and time.time() - pregunta_t < 60:
            st.update(estado="espera")              # sigue esperando tu respuesta (un minuto como mucho)
        else:
            if st["pregunta"]:
                di("Como nadie contesta, sigo con lo de siempre.")
                st["pregunta"] = ""
            r = random.random()
            if r < 0.6:
                que, dice = random.choice(tareas)
                st.update(estado="trabaja", que=que, herramienta="Bash", hechas=st["hechas"] + 1)
                if random.random() < 0.6:
                    di(frase(dice))
                if random.random() < 0.15:
                    st["ayudante"] = 2              # llama a un ayudante un rato: se ve un muñeco pequeño a su lado
                    di("Llamo a un ayudante para ir más rápido.")
            elif r < 0.75 and otro:                 # escribe al otro agente: en la página vuela un sobre 📨
                texto = frase(AVISOS.get(nombre, "{otro}, ¿todo bien?"), otro)
                apunta(os.path.join(carpeta, otro + ".buzon.jsonl"),
                       {"id": "%x" % random.getrandbits(48), "de": nombre, "texto": texto, "t": time.time()})
                st.update(estado="trabaja", que="→ " + otro, herramienta="SendMessage")
                di(texto)
            elif r < 0.85:
                st.update(estado="espera", pregunta=PREGUNTAS.get(nombre, "¿Sigo?"), que="")
                pregunta_t = time.time()
                di(st["pregunta"])
            else:
                st.update(estado="descansa", que="toma un café")
        tmp = os.path.join(carpeta, nombre + ".json.tmp")
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(dict(st, nombre=nombre, t=int(time.time())), f, ensure_ascii=False)
        os.replace(tmp, os.path.join(carpeta, nombre + ".json"))
        for _ in range(random.randint(4, 9)):
            if not vivo[0] or os.getppid() != padre or [x for x in lineas(buzon) if x.get("id") not in vistos]:
                break                               # un mensaje nuevo despierta al agente
            time.sleep(1)


if __name__ == "__main__":
    main()
